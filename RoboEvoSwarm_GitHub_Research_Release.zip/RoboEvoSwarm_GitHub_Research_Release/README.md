# RoboEvoSwarm — reproducible research implementation

**A single GitHub-ready package combining MuJoCo manipulation, RGB-D evidence, heterogeneous L1/L2/L3 interpretation, and experience-guided selection of robotic specialist capabilities.**

![Actual MuJoCo visual evidence](examples/paper_figures/mujoco_evidence_montage.png)

> **Scope and provenance.** This is the consolidated experimental source from the completed research programme, not a new simulator or a reimplementation of its core physics. The bundled sample images were saved from actual MuJoCo runs and the sample final results are a transcription of the researcher's successfully reported study. The local packaging tests do not substitute for live physics or LLM benchmarks on your machine.

## Components

- **Embodied robot:** one simulated 3-DOF tabletop robotic arm with simplified weld-based grasp.
- **L1 specialist services:** camera RGB-D segmentation, evidence verification, planning, motion control, geometric validation and outcome audit.
- **L2:** local Ollama model (tested in prior experiments using `qwen2.5:7b`) for bounded semantic interpretation.
- **L3:** optional OpenAI Responses API with structured outputs. **No API key is bundled or required for ordinary runs.**
- **Coordinator:** selects predefined lean/redundant specialist compositions, with a contextual experience table or fixed, random and event-triggered policies.
- **Environment:** object relocation, primary depth loss, simultaneous depth outages, standard and shifted scene distributions, literal, metaphor and ambiguous tasks.

LLMs propose a target identity; they do **not** directly command robot joints. Simulated cameras, evidence gates and a deterministic motion controller constrain robot actions.

## Install (Windows 11 / PowerShell; Python 3.11)

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
.\.venv\Scripts\python.exe robo_demo.py check
```

The `.env` file is private and ignored by Git. Set `OLLAMA_BASE_URL=http://127.0.0.1:11434` and `OLLAMA_MODEL=qwen2.5:7b`. Leave `OPENAI_API_KEY` blank unless you explicitly want the paid L3 baseline. Install Ollama from its official distribution and run `ollama pull qwen2.5:7b` if needed.

### Run a visual robot scenario

```powershell
.\.venv\Scripts\python.exe robo_demo.py demo --scenario moved --split test --scene-seed 50000 --scene-family standard --color blue --mode rule_fixed --disturbance depth_dropout --hold-seconds -1
```

The MuJoCo viewer stays open at the end; close it to exit. Use `--headless --hold-seconds 0` for automated physics runs.

### Run local LLM semantics

```powershell
.\.venv\Scripts\python.exe robo_demo.py reason --instruction "Move the ripe-banana-coloured block to the green target" --llm-mode local
```

### One integrated robotic evaluation (small pilot)

```powershell
.\.venv\Scripts\python.exe robo_demo.py study --repeats 2 --train 2 --test 1 --output results/confirmatory_smoke
```

### Full five-policy final comparison

```powershell
.\.venv\Scripts\python.exe robo_demo.py study --repeats 5 --train 20 --test 8 --output results/confirmatory_full
```

### Add L1-only and always-Ollama (L2) in the same experiment

```powershell
.\.venv\Scripts\python.exe robo_demo.py study --repeats 2 --train 2 --test 1 --include-reasoners --output results/reasoners_smoke
```

### Add OpenAI L3-only (billable; explicit opt-in)

```powershell
.\.venv\Scripts\python.exe robo_demo.py study --repeats 2 --train 2 --test 1 --include-reasoners --allow-openai --output results/frontier_smoke
```

The script will invoke the live model for many cases. Monitor billing. The five coordination-policy evaluation excludes OpenAI-only unless both flags are set.

### Reproduce the semantic-only routing comparison

```powershell
.\.venv\Scripts\python.exe robo_demo.py semantic-benchmark --strategy hierarchy --provider live
```

### Export paper figures from a completed robot-study directory

```powershell
.\.venv\Scripts\python.exe robo_demo.py robot-study --train 2 --test 2 --paper-images --output results/robot_study_pilot
.\.venv\Scripts\python.exe robo_demo.py figures --study results/robot_study_pilot --output results/paper_figures
```

The `figures` command is for `run_study.py`-style output. The `study` (confirmatory) runner automatically generates three measured plots from its own JSON results. Do not substitute paper figures for actual logged results.

### View sample results without installing MuJoCo

```powershell
py -3.11 robo_demo.py example-results
```

## Files

| Path | Role |
|---|---|
| `robo_demo.py` | **Single unified command-line entry point** |
| `main.py`, `assets/laboratory.xml` | Physics scene, camera observations and manipulation |
| `roboevoswarm/` | Cognition, world model/evidence, vision, experiences, simulation |
| `run_final_study.py` | Five coordination policies + optional reasoning baselines |
| `run_integrated.py` | Earlier matched end-to-end L1/L2/L3 study |
| `run_multiseed.py` | Trained vs untrained across independent training seeds |
| `benchmark_v05.py` | Standalone semantic L1/L2/L3 benchmark |
| `make_paper_figures.py` | Plots and actual-frame montage from robot study outputs |
| `examples/paper_figures/` | Actual MuJoCo images and paper graphics from earlier experiments |
| `examples/reported_results/` | Previously reported confirmatory result excerpt, with provenance |
| `docs/EXPERIMENT_GUIDE.md` | Scenarios, exact commands, figures, scoring and limitations |
| `tests/` | Original regression tests plus unified release checks |

## Research honesty

The final study found **trained adaptive = event-triggered rule** on the reported success and nominal activity metrics. Both were more efficient than always-on redundancy, and the untrained and random selectors often failed recoverable tasks. The learned module chooses between **predefined** specialist groups; it does not invent new agents or graph topology. RGB-D segmentation is classical, sensor faults are injected, and grasping is simplified. OpenAI failures from earlier tests should not be interpreted as a model-capability comparison without considering parser errors.

See `docs/EXPERIMENT_GUIDE.md` for full scoring definitions, figure provenance, and the distinction between replicates and independent scene distributions.

## Publication / repository metadata

No private keys or `.env` are included. Before publication, add author names, institutional affiliations, preferred citation, DOI or manuscript reference, and the licence selected by the code owners. This package intentionally does not assign a licence on the authors' behalf; see `LICENSE_CHOICE.md`.
