"""One preregisterable, matched L1/L2/L3/hybrid MuJoCo experiment.

Real providers only. Every test policy receives the SAME scene seed, disturbance
and instruction. Failed and unavailable runs remain in the denominator; API
failures are distinguished from safe deferrals and physical failures.
"""
from __future__ import annotations
import argparse, csv, json, os, subprocess, sys, time, hashlib
from pathlib import Path

POLICIES=('l1_only','l2_only','l3_only','fixed_hybrid','adaptive_hybrid','adaptive_untrained','rule_hybrid','random_hybrid')
DISTURBANCES=('relocation','depth_dropout')
TEMPLATES=('literal','metaphor','ambiguous')
METAPHOR={'blue':'the colour of a clear daytime sky','red':'the colour of a ripe tomato','yellow':'the colour of a ripe banana'}


def instruction_for(color,template):
    if template=='literal':return f'Move the {color} block to the green target.'
    if template=='metaphor':return f'Move the block with {METAPHOR[color]} to the green target.'
    if template=='ambiguous':return 'Move the correct block to the green target.'
    raise ValueError(template)


def make_cases(n,split,templates=TEMPLATES,disturbances=DISTURBANCES,seed_offset=0):
    return [dict(scene_seed=seed,split=split,color=('blue','red','yellow')[seed%3],
                 template=templ,disturbance=d,instruction=instruction_for(('blue','red','yellow')[seed%3],templ),
                 expected_deferral=(templ=='ambiguous'))
            for seed in range(seed_offset,seed_offset+n) for d in disturbances for templ in templates]


def case_id(case):
    return f"{case['split']}_s{case['scene_seed']:03}_{case.get('scene_family','standard')}_{case['disturbance']}_{case['template']}"


def run_one(project,root,case,policy,*,allow_openai=False,freeze=True,headless=True,paper_images=False,
            memory_path=None,force_local=False):
    experiment_id=case_id(case)
    dest=root/'runs'/policy/experiment_id
    if dest.exists():raise FileExistsError(dest)
    dest.mkdir(parents=True)
    mode=('learned' if policy in ('adaptive_hybrid','adaptive_untrained') or force_local else
          'rule_fixed' if policy=='rule_hybrid' else 'random_fixed' if policy=='random_hybrid' else 'reactive_fixed')
    # Training is handled via a separate controlled L1 exercise, below.
    cmd=[sys.executable,str(project/'main.py'), '--episodes','1','--hold-seconds','0','--output',str(dest),
         '--scene-seed',str(case['scene_seed']),'--split',case['split'],
         '--scene-family',case.get('scene_family','standard'),'--random-policy-seed',str(case.get('random_policy_seed',0)),
         '--color',case['color'],'--mode',mode,'--scenario','moved',
         '--disturbance',case['disturbance'],'--instruction',case['instruction'],
         '--semantic-policy',('l1_only' if force_local else ('adaptive_hybrid' if policy in ('adaptive_untrained','rule_hybrid','random_hybrid') else policy)),
         '--expected-color',case['color'],'--env-file',str(project/'.env')]
    if case['expected_deferral']:cmd.append('--expected-deferral')
    if allow_openai:cmd.append('--allow-openai')
    if freeze:cmd.append('--freeze-experience')
    if headless:cmd.append('--headless')
    if paper_images:cmd.append('--paper-images')
    if memory_path:cmd+=['--memory',str(memory_path)]
    t0=time.perf_counter()
    proc=subprocess.run(cmd,capture_output=True,text=True,cwd=str(project),encoding='utf-8',errors='replace')
    (dest/'console.txt').write_text(proc.stdout+'\nSTDERR:\n'+proc.stderr,encoding='utf-8')
    matches=list(dest.glob('**/summary.json'))
    if len(matches)==1:
        r=json.loads(matches[0].read_text(encoding='utf-8'))
        row={k:r.get(k) for k in ('success','end_to_end_success','correct_deferral','unsupported_commit',
               'policy_correct','grasped','placement_error_m','semantic_correct','semantic_decision',
               'reasoning_calls','llm_input_tokens','llm_output_tokens','llm_latency_ms',
               'wall_seconds','sensing_processing_ms','agent_selection_events','agent_activations',
               'nominal_graph_edges','secondary_camera_uses',
               'graph_history','error','perception_xy_errors_m','environment_outcome')}
        row['result_file']=str(matches[0].relative_to(root))
        row['infrastructure_error']=False
    else:
        row={'success':False,'end_to_end_success':False,'correct_deferral':False,
             'unsupported_commit':False,'infrastructure_error':True,
             'error':'No unique summary emitted; inspect console.txt',
             'result_file':None}
    row.update({**case,'policy':policy, 'case_id':experiment_id,'process_exit':proc.returncode,
                'total_process_seconds':round(time.perf_counter()-t0,3)})
    return row


def run(args):
    if args.test<1 or args.train<0:raise ValueError('Need >=1 test scene and >=0 train scenes')
    project=Path(__file__).resolve().parent
    root=Path(args.output).resolve()
    if root.exists():raise FileExistsError(f'Experiment folder already exists: {root} (use new --output)')
    root.mkdir(parents=True)
    policies=[p for p in POLICIES if (p!='l3_only' or args.allow_openai) and (p!='adaptive_untrained' or args.include_untrained)]
    if args.policies:
        requested=[p.strip() for p in args.policies.split(',') if p.strip()]
        unknown=set(requested)-set(policies)
        if unknown:raise ValueError(f'Unavailable strategy: {sorted(unknown)}; enable --include-untrained or --allow-openai as needed')
        policies=[p for p in policies if p in requested]
    manifest={'version':'0.7.1','title':'Matched hierarchical embodied intelligence study',
              'policies':policies,'openai_enabled':args.allow_openai,
              'train_scenes':args.train,'test_scenes':args.test,
              'train_seed_offset':args.train_seed_offset,'test_seed_offset':args.test_seed_offset,
              'untrained_ablation':args.include_untrained,
              'seed_definition':'disjoint train/test PRNG streams in scenarios.py',
              'templates':list(TEMPLATES),'disturbances':list(DISTURBANCES),
              'instruction_label_visibility':'expected target and deferral label are evaluator-only',
              'semantic_confound':'fixed_hybrid and adaptive_hybrid share routing, differ in specialist selection',
              'no_provider_cost_claims_without':'measured account billing/price specification',
              'limitations':['single 3-DOF arm','weld-based grasp','classical RGB-D segmentation',
                'announced object relocation','primary depth outage is scripted','bounded table-bandit; not topology invention',
                'LLM class selection only; safety and low-level motion remain deterministic'],
              'created_by':'run_integrated.py'}
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    rows=[]
    # The adaptive policy alone receives training; no test policy receives test outcome feedback.
    # Include training episodes explicitly in raw record, but do NOT mix them into test means.
    mem=root/'experience'/'adaptive_hybrid.json'
    mem.parent.mkdir(parents=True,exist_ok=True)
    for case in make_cases(args.train,'train',('literal',),DISTURBANCES,seed_offset=args.train_seed_offset):
        row=run_one(project,root,case,'adaptive_hybrid',freeze=False,headless=True,
                    memory_path=mem,force_local=True)
        row['policy']='adaptive_hybrid_train_l1'
        rows.append(row)
        print('TRAIN',row['case_id'],row['environment_outcome'] if 'environment_outcome' in row else row['error'],flush=True)
    # Frozen, untouched experience for the untrained counterpart.
    untrained_mem=root/'experience'/'adaptive_untrained.json'
    if args.include_untrained:untrained_mem.write_text('{}',encoding='utf-8')
    # All test conditions are matched. Independent calls are not shared across policies;
    # therefore LLM latency and nondeterminism are measured for each policy.
    for case in make_cases(args.test,'test',seed_offset=args.test_seed_offset):
        for policy in policies:
            row=run_one(project,root,case,policy,allow_openai=args.allow_openai,freeze=True,
                        headless=True,paper_images=args.paper_images and policy=='adaptive_hybrid' and case['scene_seed']==0
                        and case['template']=='literal' and case['disturbance']=='relocation',
                        memory_path=(mem if policy=='adaptive_hybrid' else untrained_mem if policy=='adaptive_untrained' else None))
            rows.append(row)
            print('TEST',row['case_id'],policy,'end_to_end=',row['end_to_end_success'],
                  'defer=',row['correct_deferral'],'infra=',row['infrastructure_error'],flush=True)
    with (root/'all_runs.json').open('w',encoding='utf-8') as f:json.dump(rows,f,indent=2)
    flat=[]
    for r in rows:
        flat.append({k:(json.dumps(v) if isinstance(v,(dict,list)) else v) for k,v in r.items()})
    cols=sorted(set().union(*(set(r) for r in flat)))
    with (root/'all_runs.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=cols);writer.writeheader();writer.writerows(flat)
    from report_integrated import make_report
    report=make_report(root)
    print('\nFINAL STUDY SUMMARY:\n'+report)
    print('Outputs:',root)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train',type=int,default=3,help='Training scene seeds (each two disturbances)')
    p.add_argument('--test',type=int,default=3,help='Held-out test scene seeds')
    p.add_argument('--output',default='results/integrated_pilot')
    p.add_argument('--allow-openai',action='store_true',help='Opt in to actual frontier calls: 6 calls per test seed (two disturbances x three templates)')
    p.add_argument('--train-seed-offset',type=int,default=0)
    p.add_argument('--test-seed-offset',type=int,default=0)
    p.add_argument('--policies',default='',help='Comma-separated subset of enabled evaluation strategies')
    p.add_argument('--include-untrained',action='store_true',help='Frozen untrained adaptive counterpart, identical held-out cases')
    p.add_argument('--paper-images',action='store_true',help='Real MuJoCo capture on one designated successful test case')
    args=p.parse_args();run(args)
if __name__=='__main__':main()
