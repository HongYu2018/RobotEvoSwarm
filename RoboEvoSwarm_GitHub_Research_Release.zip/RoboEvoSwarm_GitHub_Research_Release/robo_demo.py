#!/usr/bin/env python3
"""Single research entry point for RoboEvoSwarm. Usage: python robo_demo.py --help."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import json

ROOT = Path(__file__).resolve().parent


def invoke(script, arguments):
    cmd=[sys.executable,str(ROOT/script),*arguments]
    print('Executing:', ' '.join(str(x) for x in cmd),flush=True)
    return subprocess.call(cmd,cwd=ROOT)


def main(argv=None):
    parser=argparse.ArgumentParser(prog='robo_demo.py',description='Unified entry point for robotics, LLM reasoning, benchmarks, paper figures, and tests.',
        epilog='Detailed scenario instructions: see README.md and docs/EXPERIMENT_GUIDE.md.')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('check',help='Run pytest plus basic compilation smoke checks')
    p=sub.add_parser('demo',help='MuJoCo scene demonstration; forwards all main.py options')
    p=sub.add_parser('reason',help='Live L1/L2/L3 semantic reasoning demo; forwards semantic_demo.py options')
    p=sub.add_parser('semantic-benchmark',help='14-case semantic routing benchmark')
    p=sub.add_parser('study',help='Five-policy confirmatory study and optional L1/L2/L3 comparisons')
    p=sub.add_parser('integrated',help='Integrated L1/L2/L3 embodied experiment')
    p=sub.add_parser('multiseed',help='Trained/untrained independent-seed ablation')
    p=sub.add_parser('robot-study',help='Earlier robot coordination study')
    p=sub.add_parser('figures',help='Generate plots and real frame montages from a robot study')
    p=sub.add_parser('openai-diagnostics',help='Classify per-case OpenAI failures')
    p=sub.add_parser('example-results',help='Display bundled previously reported outcomes')
    # Delegate script-specific --help instead of displaying the wrapper's empty subparser.
    raw = list(sys.argv[1:] if argv is None else argv)
    if len(raw) >= 2 and raw[0] in ('demo','reason','semantic-benchmark','study','integrated','multiseed','robot-study','figures','openai-diagnostics') and raw[1] in ('-h','--help'):
        help_scripts={'demo':'main.py','reason':'semantic_demo.py','semantic-benchmark':'benchmark_v05.py','study':'run_final_study.py','integrated':'run_integrated.py','multiseed':'run_multiseed.py','robot-study':'run_study.py','figures':'make_paper_figures.py','openai-diagnostics':'diagnose_openai.py'}
        return invoke(help_scripts[raw[0]], ['--help'])
    args, forwarded=parser.parse_known_args(argv)
    if args.command=='check':
        import compileall
        ok=compileall.compile_dir(str(ROOT),quiet=1)
        if not ok:return 1
        return subprocess.call([sys.executable,'-m','pytest','-q','tests'],cwd=ROOT)
    if args.command=='example-results':
        print((ROOT/'examples/reported_results/FINAL_CONFIRMATORY_RETRY_excerpt.json').read_text(encoding='utf-8'))
        return 0
    scripts={'demo':'main.py','reason':'semantic_demo.py', 'semantic-benchmark':'benchmark_v05.py',
       'study':'run_final_study.py','integrated':'run_integrated.py','multiseed':'run_multiseed.py',
       'robot-study':'run_study.py','figures':'make_paper_figures.py','openai-diagnostics':'diagnose_openai.py'}
    if forwarded and forwarded[0]=='--': forwarded=forwarded[1:]
    return invoke(scripts[args.command],forwarded)

if __name__=='__main__':
    raise SystemExit(main())
