"""Fail-inclusive numerical report and plot export from real integrated study results."""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
from statistics import mean
from collections import defaultdict

METRICS=('end_to_end_success','correct_deferral','unsupported_commit','infrastructure_error',
         'reasoning_calls','llm_input_tokens','llm_output_tokens','llm_latency_ms',
         'wall_seconds','sensing_processing_ms','agent_activations','agent_selection_events',
         'nominal_graph_edges','secondary_camera_uses')

def avg(group,k):
    vals=[x.get(k) for x in group if isinstance(x.get(k),(int,float,bool))]
    return sum(vals)/len(group) if vals else None

def rate(group,k):return sum(bool(x.get(k)) for x in group)/len(group) if group else None

def wilson(success,n,z=1.96):
    if not n:return None
    p=success/n; d=1+z*z/n; c=(p+z*z/(2*n))/d
    h=z*(p*(1-p)/n+z*z/(4*n*n))**.5/d
    return [round(max(0,c-h),4),round(min(1,c+h),4)]

def summarise(rows):
    test=[r for r in rows if r['split']=='test']
    groups=defaultdict(list)
    for r in test:groups[r['policy']].append(r)
    result={}
    for name,g in groups.items():
        semantic=[x for x in g if not x['expected_deferral']]
        ambiguous=[x for x in g if x['expected_deferral']]
        success=sum(bool(x.get('end_to_end_success')) for x in semantic)
        result[name]={'n':len(g),'actionable_n':len(semantic),
                'physical_and_semantic_successes':success,
                'end_to_end_actionable_success_rate':rate(semantic,'end_to_end_success'),
                'success_wilson_95':wilson(success,len(semantic)),
                'ambiguous_n':len(ambiguous), 'correct_deferral_rate':rate(ambiguous,'correct_deferral'),
                'unsupported_commits':sum(bool(x.get('unsupported_commit')) for x in g),
                'depth_dropout_actionable_success_rate':rate([x for x in semantic if x['disturbance']=='depth_dropout'],'end_to_end_success'),
                'relocation_actionable_success_rate':rate([x for x in semantic if x['disturbance']=='relocation'],'end_to_end_success'),
                'infrastructure_failures':sum(bool(x.get('infrastructure_error')) for x in g),
                'means':{k:avg(g,k) for k in METRICS if k not in ('end_to_end_success','correct_deferral','unsupported_commit','infrastructure_error')},
                'total_llm_calls':sum(x.get('reasoning_calls') or 0 for x in g),
                'total_llm_tokens':sum((x.get('llm_input_tokens') or 0)+(x.get('llm_output_tokens') or 0) for x in g),
                'failure_examples':[{'id':x['case_id'],'error':x.get('error'),
                    'decision':x.get('semantic_decision')} for x in g if
                    (x['expected_deferral'] and not x.get('correct_deferral')) or
                    (not x['expected_deferral'] and not x.get('end_to_end_success'))][:15]}
    return result

def make_report(root):
    root=Path(root)
    rows=json.loads((root/'all_runs.json').read_text(encoding='utf-8'))
    agg=summarise(rows)
    (root/'aggregate.json').write_text(json.dumps(agg,indent=2),encoding='utf-8')
    lines=['# RoboEvoSwarm v0.7.1 — integrated experiment report','',
           'This report is generated from real run outputs. No missing method or failed episode is imputed as successful.',
           'Training and test splits are separated. Success rates for actionable tasks exclude intentionally ambiguous cases, which are scored by correct deferral.','',
           '| Policy | End-to-end on actionable tasks | Correct ambiguous deferral | Unsafe commits | LLM calls | Tokens | Mean activations | Mean wall time (s) |',
           '|---|---:|---:|---:|---:|---:|---:|---:|']
    for p,v in agg.items():
        def fmt(q):return 'N/A' if q is None else f'{100*q:.1f}%'
        def num(k):
            x=v['means'].get(k);return 'N/A' if x is None else f'{x:.3f}'
        lines.append(f"| {p} | {v['physical_and_semantic_successes']}/{v['actionable_n']} ({fmt(v['end_to_end_actionable_success_rate'])}) | {fmt(v['correct_deferral_rate'])} | {v['unsupported_commits']} | {v['total_llm_calls']} | {v['total_llm_tokens']} | {num('agent_activations')} | {num('wall_seconds')} |")
    lines.extend(['','## Notes on validity','',
                  '- Semantic benchmark: literal, indirect and deliberately ambiguous instructions. Ambiguous tasks should defer.',
                  '- Physical benchmark: deterministic MuJoCo arm with RGB-D observations, relocation and primary-depth failure, evaluated over held-out scenes.',
                  '- The two hybrid conditions use the same semantic routing; specialist topology selection differs.',
                  '- L2-only and L3-only explicitly invoke the corresponding model even for literal instructions. They do not receive private expected labels.',
                  '- OpenAI-only results are absent when the run did not explicitly enable OpenAI. No zero-filled fictitious results are supplied.',
                  '- Agent activation and edge counts are nominal graph events; wall time includes LLM and simulation (plus startup) and cannot by itself attribute CPU efficiency.',
                  '- Correct deferral under ambiguity is a positive safety outcome, not a completed manipulation.',
                  '- A contextual-bandit selecting from predefined capability compositions is not autonomous invention of agents or topology.',
                  '- Claim of learned coordination requires independent training repeats and comparison against adaptive_untrained. If adaptive_untrained is absent, that ablation is not run.',
                  '- Small-sample Wilson intervals quantify binomial uncertainty, not dependence between scenes or model-call stochasticity.',
                  '', '## Failure diagnostics', ''])
    for p,v in agg.items():
        lines.append(f"### {p} — infrastructure failures: {v['infrastructure_failures']}")
        for item in v['failure_examples'][:6]:lines.append(f"- `{item['id']}`: {str(item['error'])[:130]}")
        if not v['failure_examples']:lines.append('- No failing cases in this run.')
    report='\n'.join(lines)+'\n'
    (root/'REPORT.md').write_text(report,encoding='utf-8')
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        policies=list(agg)
        for key,filename,label in [
            ('end_to_end_actionable_success_rate','fig_end_to_end_success.png','End-to-end actionable-task success rate'),
            ('correct_deferral_rate','fig_ambiguity_deferral.png','Correct deferral on ambiguous tasks')]:
            vals=[agg[p][key] or 0 for p in policies]
            fig,ax=plt.subplots(figsize=(9,4.5));ax.bar(policies,vals);ax.set_ylim(0,1.05)
            ax.set_ylabel(label);ax.tick_params(axis='x',rotation=25);fig.tight_layout()
            fig.savefig(root/filename,dpi=220);plt.close(fig)
        for key,filename,label in [('total_llm_calls','fig_llm_calls.png','Total live model calls'),
                                    ('total_llm_tokens','fig_llm_tokens.png','Total model tokens')]:
            fig,ax=plt.subplots(figsize=(9,4.5));ax.bar(policies,[agg[p][key] for p in policies])
            ax.set_ylabel(label);ax.tick_params(axis='x',rotation=25);fig.tight_layout()
            fig.savefig(root/filename,dpi=220);plt.close(fig)
    except ImportError:
        report+='\nPlots not exported: matplotlib unavailable. Raw CSV/JSON and report are intact.\n'
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--study',required=True);a=p.parse_args()
    print(make_report(a.study))
