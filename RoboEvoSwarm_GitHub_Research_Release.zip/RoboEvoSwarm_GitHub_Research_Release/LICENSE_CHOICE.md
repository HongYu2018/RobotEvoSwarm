# Licence selection required before public GitHub release

The copyright holders should choose a suitable licence (for example MIT, BSD-3-Clause, or Apache-2.0) and insert an actual `LICENSE` file before making the repository public. No licence is granted by the absence of a licence file. Check University of Derby and any other partners' software/foreground-IP arrangements first. The bundled MuJoCo outputs and manuscript images should also be included only with the relevant project rights.
