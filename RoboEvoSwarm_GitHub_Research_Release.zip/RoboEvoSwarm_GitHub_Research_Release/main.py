"""RoboEvoSwarm v0.3: RGB/depth observation + evidence gate + contextual graph memory.

Simulation execution should be validated on Windows.  No actual robot support.
"""
from __future__ import annotations
import argparse
import csv
import json
import time
from dataclasses import asdict
from pathlib import Path
import numpy as np
import mujoco
from mujoco import viewer as mujoco_viewer
from roboevoswarm.reasoning import load_env, resolve_task, resolve_policy, Decision
from roboevoswarm.evidence import fixture_ledger
from roboevoswarm.simulation import Laboratory
from roboevoswarm.vision import RGBDObserver
from roboevoswarm.adaptation import ContextualSelector, Experience
from roboevoswarm.scenarios import scene_spec, verify_scene_split
from roboevoswarm.legacy import COLORS, NAME, EmbodiedWorldModel, SimulatedPoseSensor, pick_waypoints, drop_waypoints


def run_episode(args, episode, experience):
    lab, wm = Laboratory(), EmbodiedWorldModel()
    reasoning_trace = []
    decision = None
    if args.instruction:
        if args.semantic_policy:
            decision, reasoning_trace = resolve_policy(args.instruction, args.semantic_policy,
                                                      allow_openai=args.allow_openai)
        else:
            decision, reasoning_trace = resolve_task(args.instruction,mode=args.llm_mode,
                                                      allow_openai=args.allow_openai)
        if decision.color is not None:
            args.color = decision.color

    # Seeded perturbations are evaluator-controlled. They are not passed to the
    # perception or agent policy except through observable camera images and
    # announced events. Keep geometry within this 3-DOF arm's tested workspace.
    # Scene layout and intervention are determined by the evaluator's intended
    # target, never by a model proposal; incorrect proposals cannot change the task.
    scene_color = args.expected_color or args.color
    spec = scene_spec(args.scene_seed, args.split, args.disturbance, scene_color, args.scene_family)
    lab.relocate_object(NAME[scene_color], spec['initial_pose'])
    others = [c for c in ('red','blue','yellow') if c != scene_color]
    for other, xyz in zip(others, spec['distractor_poses']):
        lab.relocate_object(NAME[other], xyz)
    lab.playback_speed = args.speed
    selector = ContextualSelector(args.mode, experience, random_seed=args.scene_seed + args.random_policy_seed)
    output = Path(args.output) / f'{args.scenario}_{args.mode}_{args.color}' / f'episode_{episode:03}'
    output.mkdir(parents=True, exist_ok=True)
    viewer, observer, observer_b = None, None, None
    grasped = success = False
    error = None
    target = np.array([.34, .27, .055])
    pose = None
    start_wall = time.perf_counter()
    sensing_ms = 0.0
    observations = []
    figures = []
    capture = None
    evidence_gate = None

    def photograph(label):
        if not args.paper_images:
            return
        try:
            if capture is None:
                return
            capture.update_scene(lab.data, camera='lab_camera')
            rgb = capture.render().copy()
            from PIL import Image
            file = output / f'figure_{label}.png'
            Image.fromarray(rgb).save(file)
            figures.append({'label':label,'file':file.name,'sim_time':round(lab.t,3)})
        except Exception as exc:
            wm.log(lab.t, 'paper_capture_failure', stage=label, error=str(exc)[:120])

    def select(stage, condition):
        row = selector.select(stage, condition, lab.t)
        wm.log(lab.t, 'agent_selection', **{k:v for k,v in row.items() if k != 't'})
        return row

    def sense(label, reason):
        nonlocal sensing_ms, observer_b
        selection = select('sense', reason)
        if args.perception == 'rgbd':
            result = observer.observe(args.color, output / label, depth_dropout=(args.disturbance in ('depth_dropout','dual_depth_dropout') and label != 'before'))
            sensing_ms += result.runtime_ms
            record = asdict(result)
            observations.append(record)
            wm.log(lab.t, 'rgbd_capture', **record)
            if 'depth_crosscheck' in selection['agents']:
                repeat = observer.observe(args.color, output / f'{label}_check', depth_dropout=(args.disturbance in ('depth_dropout','dual_depth_dropout') and label != 'before'))
                sensing_ms += repeat.runtime_ms
                observations.append(asdict(repeat))
                wm.log(lab.t, 'rgbd_crosscheck', **asdict(repeat))
                if result.xyz is not None and repeat.xyz is not None:
                    delta = float(np.linalg.norm(np.array(result.xyz[:2])-np.array(repeat.xyz[:2])))
                    wm.log(lab.t, 'rgbd_agreement', horizontal_disagreement_m=round(delta, 4))
                    if delta > .035:
                        result.status = 'uncertain'
                else:
                    result.status = 'missing'
            if result.xyz is None or result.status != 'fresh':
                wm.log(lab.t, 'uncertain_evidence', reason=reason, confidence=result.confidence,
                       uncertainty_m=result.uncertainty_m)
                # A genuine additional sensing capability, not only a graph
                # counter: request a second physical camera's RGB-D render.
                if args.disturbance in ('depth_dropout','dual_depth_dropout') and label != 'before':
                    recovery=select('recover','primary_depth_missing')
                    if 'second_rgbd_camera' in recovery['agents']:
                        if observer_b is None:
                            observer_b=RGBDObserver(lab,camera_name='lab_camera_b')
                        alternate=observer_b.observe(args.color, output/f'{label}_secondary', depth_dropout=(args.disturbance=='dual_depth_dropout'))
                        observations.append(asdict(alternate))
                        sensing_ms += alternate.runtime_ms
                        wm.log(lab.t,'secondary_rgbd_capture',**asdict(alternate))
                        if alternate.xyz is not None and alternate.status=='fresh':
                            result=alternate
                if result.xyz is None or result.status != 'fresh':
                    return None
            wm.observe(NAME[args.color], result.xyz, lab.t, source=result.source)
            wm.beliefs[args.color]['confidence'] = result.confidence
            wm.beliefs[args.color]['uncertainty_m'] = result.uncertainty_m
            return np.asarray(result.xyz)
        select('verify', 'debug_oracle')
        result = SimulatedPoseSensor().sense(lab, args.color, wm)
        wm.log(lab.t, 'oracle_debug_observation')
        return np.asarray(result.xyz)

    try:
        if args.instruction:
            wm.log(lab.t,'semantic_preflight',instruction=args.instruction,
                   decision=decision.public_dict(),reasoning_trace=reasoning_trace)
            if decision.color is None:
                raise RuntimeError('Action safely deferred: ambiguous or unresolved semantic target')
        # Deliberately injected epistemic conditions for experimental auditing;
        # not a claim of real sensor fusion. We never access object ground truth
        # to override conflict, stale or missing claims.
        injected = fixture_ledger(args.evidence_case, args.color)
        evidence_gate = injected.evaluate('target', 'colour', now=10.)
        wm.log(lab.t, 'semantic_evidence_gate', case=args.evidence_case,
               status=evidence_gate['status'], sources=evidence_gate['sources'])
        if evidence_gate['status'] != 'fresh':
            raise RuntimeError('Action safely deferred: '+evidence_gate['status']+
                               ' semantic evidence (injected evaluation condition)')
        if args.perception == 'rgbd':
            observer = RGBDObserver(lab)
            # Secondary camera is constructed lazily only when policy activates it.
        if args.paper_images:
            from PIL import Image
            capture = mujoco.Renderer(lab.model, height=600, width=800)
        if not args.headless:
            viewer = mujoco_viewer.launch_passive(lab.model, lab.data)
        wm.log(lab.t, 'task', color=args.color, scenario=args.scenario, mode=args.mode,
               perception=args.perception)
        print(f'\nEPISODE {episode}: move {args.color} block to green target; {args.perception} / {args.mode}')
        photograph('01_initial')
        pose = sense('before', 'initial')
        print('Initial camera estimate:', None if pose is None else np.round(pose, 4).tolist())
        if args.scenario == 'moved':
            lab.relocate_object(NAME[scene_color], spec['moved_pose'])
            wm.invalidate(scene_color, lab.t, 'announced_external_object_relocation')
            wm.log(lab.t, 'external_event_notice', event_type='relocation', color=scene_color)
            print('EVENT: target relocated after original camera observation')
            photograph('02_relocated')
            if viewer is not None:
                viewer.sync()
                time.sleep(.5 / args.speed)
        elif args.scenario != 'static':
            raise ValueError(args.scenario)
        verification = select('verify', 'stale' if not wm.fresh(args.color) else 'fresh')
        if not wm.fresh(args.color) or pose is None:
            pose = sense('after', 'stale_or_missing')
            print('Updated camera estimate:', None if pose is None else np.round(pose, 4).tolist())
        photograph('03_reobserved')
        if 'reobservation' in verification['agents'] and pose is not None and wm.fresh(args.color):
            # Optional independent refresh instead of only nominal graph membership.
            checked_pose = sense('verification', 'optional_verification')
            if checked_pose is None or np.linalg.norm(checked_pose[:2] - pose[:2]) > .035:
                raise RuntimeError('Optional verification found inconsistent object location')
            pose = checked_pose
        # Hard evidence gate protects all strategies. It never substitutes hidden state.
        if pose is None or not wm.fresh(args.color):
            raise RuntimeError('Action safely deferred: camera evidence missing/uncertain')
        lab.choose_object(NAME[args.color])  # actuator selection by requested identity, not pose retrieval
        plan_graph = select('plan', 'fresh')
        if 'geometric_recheck' in plan_graph['agents']:
            # Executed workspace / finite-value check (not simulator ground truth).
            if not np.all(np.isfinite(pose)) or not (.12 < pose[0] < .70 and abs(pose[1]) < .36):
                raise RuntimeError('Geometric workspace recheck rejected target pose')
            wm.log(lab.t, 'geometric_recheck', passed=True)
        for name, waypoint, duration in pick_waypoints(pose):
            select('execute', 'manipulation')
            err = lab.step_to(waypoint, duration, viewer)
            wm.log(lab.t, 'waypoint', name=name, error_m=round(err, 4))
            print(f'{name:23} tip_error={err:.3f}m')
        photograph('04_pregrasp')
        grasped, gap = lab.grasp()
        wm.log(lab.t, 'grasp', success=grasped, distance_m=round(gap, 4))
        print('grasp:', grasped, 'tool-to-object:', round(gap, 4))
        if grasped:
            for name, waypoint, duration in drop_waypoints():
                if name == 'lift':
                    waypoint = (float(pose[0]), float(pose[1]), .24)
                select('execute', 'manipulation')
                err = lab.step_to(waypoint, duration, viewer)
                dist = lab.block_tool_distance()
                wm.log(lab.t, 'waypoint', name=name, error_m=round(err,4), separation_m=round(dist,4))
                print(f'{name:23} tip_error={err:.3f}m separation={dist:.3f}m')
                if name == 'lift': photograph('05_lift')
                if name == 'travel_above_target': photograph('06_transport')
                if dist > .115 or lab.block[2] < .034:
                    raise RuntimeError('Grasp lost: ' + lab.diagnostics())
            lab.release()
            lab.step_to((.34, .27, .24), 3.5, viewer)
        for k in range(400):
            mujoco.mj_step(lab.model, lab.data)
            if viewer is not None and k % 10 == 0:
                viewer.sync()
                time.sleep(10 * lab.model.opt.timestep / args.speed)
        photograph('07_final')
        select('audit', 'outcome')
        final = lab.object_position(NAME[args.color]) # evaluator-only; NOT perception input
        placement = float(np.linalg.norm(final[:2] - target[:2]))
        horizontal_ok = bool(placement < .07)
        vertical_error = float(abs(final[2] - target[2]))
        vertical_ok = bool(vertical_error < .08)
        success = bool(grasped and horizontal_ok and vertical_ok)
        wm.log(lab.t, 'evaluated_outcome', success=success, placement_error_m=round(placement,4),
               final_object_xyz_m=final.tolist(), vertical_error_m=round(vertical_error,4),
               horizontal_ok=horizontal_ok, vertical_ok=vertical_ok)
    except (RuntimeError, ValueError, ImportError) as exc:
        error = str(exc)
        wm.log(lab.t, 'failure', message=error)
        print('EXPERIMENT ERROR:', error)
    finally:
        # Safety deferral is recorded independently; for experience rewards,
        # completing the task with a valid fallback should outperform deferral.
        learning_success = bool(success)
        if not args.freeze_experience: selector.learn(learning_success)
        final = lab.object_position(NAME[args.color])
        placement = float(np.linalg.norm(final[:2] - target[:2]))
        ground_initial = spec['initial_pose']
        ground_after = spec['moved_pose'] if args.scenario == 'moved' else spec['initial_pose']
        position_err = [float(np.linalg.norm(np.array(row['xyz'][:2])-np.array(ground_initial[:2] if ix==0 else ground_after[:2])))
                        if row.get('xyz') is not None else None for ix,row in enumerate(observations)]
        expected_deferral = False  # a secondary sensor exists; do not assume task is impossible
        safe_deferral = (not success and not grasped and error is not None and 'safely deferred' in error)
        policy_correct = bool(success or safe_deferral)  # coarse safety-or-completion endpoint
        report = {'policy_correct':policy_correct,'expected_deferral':expected_deferral,
                  'safe_deferral':bool(safe_deferral),'scene_seed':args.scene_seed, 'split':args.split, 'disturbance':args.disturbance,
                  'experiment_spec':spec, 'scene_family':args.scene_family, 'perception_xy_errors_m':position_err,
                  'paper_images':figures,'experience_frozen':bool(args.freeze_experience),
                  'success': bool(success), 'episode': episode, 'scenario':args.scenario,
                  'mode': args.mode, 'perception': args.perception, 'color': args.color,
                  'grasped': bool(grasped), 'placement_error_m': round(placement,4),
                  'final_object_xyz_m': [round(float(v),5) for v in final],
                  'height_error_m': round(float(abs(final[2]-target[2])),5),
                  'grasp_condition_met': bool(grasped),
                  'horizontal_condition_met': bool(placement < .07),
                  'height_condition_met': bool(abs(final[2]-target[2]) < .08),
                  'simulation_seconds':round(lab.t,2), 'wall_seconds':round(time.perf_counter()-start_wall,3),
                  'sensing_processing_ms':round(sensing_ms,3),
                  'agent_selection_events':len(selector.trace),
                  'agent_activations':sum(len(x['agents']) for x in selector.trace),
                  'nominal_graph_edges':sum(len(x.get('edges',[])) for x in selector.trace),
                  'secondary_camera_uses':sum(str(x.get('source','')).startswith('lab_camera_b:') for x in observations),
                  'instruction': args.instruction, 'semantic_decision':decision.public_dict() if decision else None,
                  'semantic_policy': args.semantic_policy or args.llm_mode,
                  'intended_color': args.expected_color, 'scene_color': scene_color,
                  'semantic_correct': (decision.color == args.expected_color) if decision is not None and args.expected_color else None,
                  'end_to_end_success': bool(success and (not args.expected_color or (decision is not None and decision.color == args.expected_color))),
                  'correct_deferral': bool(args.expected_deferral and not grasped and error is not None and ('deferred' in error or 'unresolved' in error)),
                  'unsupported_commit': bool(grasped and (args.expected_deferral or (args.expected_color and (decision is None or decision.color != args.expected_color)))),
                  'environment_outcome': ('completed' if success else ('safe_deferral' if (not grasped and error and 'deferred' in error) else 'failure')),
                  'evidence_case': args.evidence_case, 'evidence_gate': evidence_gate,
                  'reasoning_calls':sum(x.get('source') in ('ollama','openai') for x in reasoning_trace),
                  'llm_input_tokens':sum(x.get('input_tokens',0) for x in reasoning_trace),
                  'llm_output_tokens':sum(x.get('output_tokens',0) for x in reasoning_trace),
                  'llm_latency_ms':round(sum(x.get('latency_ms',0) for x in reasoning_trace),2),
                  'reasoning_trace':reasoning_trace,
                  'graph_history':selector.trace, 'observations':observations,
                  'error':error, 'limitations': ('Bounded semantic interpretation; v0.5 evidence-case fixtures are scripted, not physical multi-sensor fusion; not multimodal VLM inference; Classical RGB colour segmentation and MuJoCo depth; known cube dimensions/table height; '
                     'simplified weld-based grasp; announced relocation event; outcome-only contextual-bandit updates; '
                     'not a learned VLM, autonomous topology invention, calibrated probabilistic uncertainty, or ROS system.')}
        (output/'summary.json').write_text(json.dumps(report, indent=2),encoding='utf-8')
        (output/'world_model.json').write_text(json.dumps(wm.__dict__, indent=2),encoding='utf-8')
        with (output/'events.csv').open('w',newline='',encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['simulation_time','event','details'])
            for ev in wm.history:
                writer.writerow([ev['t'], ev['event'], json.dumps({k:v for k,v in ev.items() if k not in ('t','event')})])
        print('\nRESULT:',json.dumps({k:v for k,v in report.items() if k not in ('graph_history','observations')},indent=2))
        print('Output:',output.resolve())
        if viewer is not None and viewer.is_running() and args.hold_seconds != 0:
            print('Final scene held. Close MuJoCo window to exit.' if args.hold_seconds < 0 else 'Holding final scene.')
            s=time.perf_counter()
            while viewer.is_running() and (args.hold_seconds < 0 or time.perf_counter()-s < args.hold_seconds):
                viewer.sync()
                time.sleep(.05)
        if viewer is not None: viewer.close()
        if observer is not None: observer.close()
        if observer_b is not None: observer_b.close()
        if capture is not None: capture.close()
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--scene-seed',type=int,default=11,help='Reproducible environment layout seed')
    p.add_argument('--split',choices=['train','test'],default='train',help='Disjoint scene randomisation distributions')
    p.add_argument('--scene-family',choices=['standard','shifted'],default='standard')
    p.add_argument('--random-policy-seed',type=int,default=0)
    p.add_argument('--disturbance',choices=['none','relocation','depth_dropout','dual_depth_dropout'],default='relocation',
                   help='Physically relocate object, or inject a depth-sensor outage after relocation')
    p.add_argument('--paper-images',action='store_true',help='Capture REAL MuJoCo frames at execution milestones')
    p.add_argument('--freeze-experience',action='store_true',help='No learning during held-out evaluation')
    p.add_argument('--scenario',choices=['moved','static'],default='moved')
    p.add_argument('--instruction',default='',help='Optional natural-language task; unknown target invokes selective LLM')
    p.add_argument('--semantic-policy',choices=['l1_only','l2_only','l3_only','fixed_hybrid','adaptive_hybrid'],default=None,
                   help='Integrated experimental condition, explicit always-model baselines')
    p.add_argument('--expected-color',choices=COLORS,default=None,help='Evaluator reference only; NEVER given to policy')
    p.add_argument('--expected-deferral',action='store_true',help='Evaluator label for unresolvable instruction')
    p.add_argument('--evidence-case',choices=['clear','conflict','stale','missing'],default='clear',
                   help='Controlled evidence injection; conflict/stale/missing must defer without actuation')
    p.add_argument('--llm-mode',choices=['none','local','auto','frontier'],default='auto')
    p.add_argument('--allow-openai',action='store_true',help='Explicit opt-in to billable frontier API calls')
    p.add_argument('--env-file',default='.env')
    p.add_argument('--mode',choices=['learned','lean_fixed','reactive_fixed','rule_fixed','random_fixed'],default='learned')
    p.add_argument('--perception',choices=['rgbd','oracle'],default='rgbd',
                   help='oracle is debug-only and cannot support vision research claims')
    p.add_argument('--color',choices=COLORS,default='blue')
    p.add_argument('--headless',action='store_true')
    p.add_argument('--speed',type=float,default=1.)
    p.add_argument('--hold-seconds',type=float,default=-1.)
    p.add_argument('--episodes',type=int,default=1)
    p.add_argument('--output',default='results')
    p.add_argument('--memory',default='results/experience.json')
    a=p.parse_args()
    load_env(a.env_file)
    verify_scene_split(a.scene_seed,a.split)
    if a.speed <= 0 or a.episodes < 1: p.error('--speed must be positive and --episodes >= 1')
    memory=Experience.load(a.memory) if a.mode == 'learned' else Experience()
    reports=[]
    for ep in range(1,a.episodes+1):
        # Multi-episode benchmark is normally headless to avoid held viewer between trials.
        if a.episodes > 1:
            a.headless = True
            a.hold_seconds = 0
        reports.append(run_episode(a,ep,memory))
        if a.mode == 'learned':
            Path(a.memory).parent.mkdir(parents=True,exist_ok=True)
            memory.save(a.memory)
    print('\nAGGREGATE:',json.dumps({'n':len(reports), 'successes':sum(r['success'] for r in reports),
           'mean_activations':round(np.mean([r['agent_activations'] for r in reports]),2)},indent=2))
    raise SystemExit(0 if all(r['success'] for r in reports) else 1)

if __name__ == '__main__':main()
