"""Diagnose v0.5 frontier-only results WITHOUT making extra API calls.

Usage: python diagnose_openai.py --input PATH\n
Input is the frontier_only_live.json exported by benchmark_v05.py.
The tool does not expose or log API keys and avoids publishing raw prompts by default.
"""
from __future__ import annotations
import argparse
from collections import Counter
from pathlib import Path
import json


def categorize(row):
    trace=row.get('trace') or []
    problems=[item.get('error') for item in trace if item.get('error')]
    if problems:
        err=str(problems[0]); short=err.split(':',1)[0]
        return 'provider_or_parse_error',short
    if row.get('evidence_status') != 'fresh':
        return ('correct_safety_deferral' if row.get('correct') else 'evidence_gate_mismatch'),row.get('evidence_status')
    if row.get('expected') in (None,'') and row.get('committed') is not None:
        return 'unsupported_commit','ambiguous instruction selected a target'
    if row.get('expected') not in (None,'') and row.get('committed') is None:
        return 'incorrect_deferral','model returned no accepted colour'
    if row.get('committed') != row.get('expected'):
        return 'wrong_colour','accepted proposal differs from expected label'
    return 'other','review per-case trace'


def analyse(data):
    rows=data['rows']; failures=[]
    for r in rows:
        if r['correct']: continue
        category,detail=categorize(r)
        failures.append({'id':r['id'],'family':r['family'],'expected':r.get('expected'),
                         'proposed':r.get('proposed'),'committed':r.get('committed'),
                         'category':category,'detail':detail,
                         'model_error':[t.get('error') for t in r.get('trace',[]) if t.get('error')]})
    return {'reported':data.get('summary',{}),'failure_categories':dict(Counter(x['category'] for x in failures)),
            'failures':failures,'scope':'The benchmark tests prompting, provider formatting, parser, and evidence gate together.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True)
    p.add_argument('--output',default='results/openai_diagnostic.json')
    a=p.parse_args(); report=analyse(json.loads(Path(a.input).read_text(encoding='utf-8')))
    output=Path(a.output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
