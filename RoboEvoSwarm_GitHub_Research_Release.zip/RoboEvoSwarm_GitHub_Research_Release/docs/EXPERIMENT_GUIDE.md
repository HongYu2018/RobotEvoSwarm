# Complete research demonstrations and experimental guide

All commands below are issued inside the repository root. For Windows, replace `python` with `.\.venv\Scripts\python.exe` if not using an activated virtual environment. Every example uses `robo_demo.py`.

## 1. Scientific system definition

**Embodied robot** = one physical simulated arm + sensors + planner/controller + multiple software specialists. **Specialist agent** = a bounded capability behind a callable cognitive interface (not an additional physical robot). The coordinator chooses which specialist configuration is active, not how to write motor commands with an LLM.

- L1: structured parsing, RGB-D detection, geometric planning and verification.
- L2: local Ollama small LLM, only if appropriate under hybrid routing.
- L3: optional paid OpenAI model, explicitly enabled.
- World model: scene state, timestamped observation history, evidence/provenance and control-relevant beliefs. The implementation is a limited experimental analogue of the full research conceptual world model, not a general causal dynamics learner.
- Selector: fixed redundant, failure-triggered rule, random, trained contextual bandit, or untrained bandit.

## 2. Installation and environment checks

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe robo_demo.py check
.\.venv\Scripts\python.exe -c "import mujoco; print(mujoco.__version__)"
```

For Ollama, `ollama list`, `ollama pull qwen2.5:7b`, and `Invoke-RestMethod http://127.0.0.1:11434/api/tags` check availability. If a university-managed Windows policy prevents the MuJoCo native extension loading, work with IT; do not bypass security controls.

## 3. Demonstrable robotic scenarios (live MuJoCo)

### A. Ordinary relocation — visual result

```powershell
python robo_demo.py demo --scenario moved --split test --scene-seed 50000 --scene-family standard --color blue --mode reactive_fixed --disturbance relocation --hold-seconds -1
```

Expect object relocation, updated RGB-D localisation, grasp and place. Screenshot the initial scene and final object on green target. A scene screenshot is qualitative and cannot establish independent sensor use by itself.

### B. Primary camera depth loss — alternative-camera recovery

```powershell
python robo_demo.py demo --scenario moved --split test --scene-seed 50000 --scene-family standard --color blue --mode rule_fixed --disturbance depth_dropout --hold-seconds -1
```

Check the **actual** `secondary_camera_uses` field and logged sensor source before claiming recovery used camera B. Successful recoverable action should be scored as 1; optional traces in JSON record graph activation.

### C. Dual-camera depth loss — correct abstention

```powershell
python robo_demo.py demo --scenario moved --split test --scene-seed 50000 --scene-family standard --color blue --mode rule_fixed --disturbance dual_depth_dropout --headless --hold-seconds 0
```

A non-zero exit status due to safe deferral is expected. This is **not** a successful physical manipulation; it is a correct safety decision.

### D. Shifted scene layout

```powershell
python robo_demo.py demo --scenario moved --split test --scene-seed 50000 --scene-family shifted --color blue --mode rule_fixed --disturbance relocation --hold-seconds -1
```

The shifted distribution uses a different nearby location range, not open-world generalisation.

### E. Indirect instruction, real Ollama

```powershell
python robo_demo.py demo --scenario moved --color yellow --instruction "Move the ripe-banana-coloured block to the green target" --llm-mode local --disturbance relocation --hold-seconds -1
```

Inspect semantic decision source/model/latency/tokens in the episode output.

### F. Ambiguous or conflicting evidence

```powershell
python robo_demo.py demo --scenario moved --color blue --instruction "Move the correct block" --llm-mode auto --headless --hold-seconds 0
python robo_demo.py demo --scenario moved --color blue --instruction "Move the blue block" --evidence-case conflict --llm-mode auto --headless --hold-seconds 0
```

The appropriate outcome can be safe abstention; inspect `correct_deferral`, `unsupported_commit`, and the explicit `error` reason rather than treating exit code alone as task success.

## 4. Matched comparison matrix

| Independent factor | Values | Interpretation |
|---|---|---|
| Scene family | standard, shifted | New held-out scene geometry |
| Disturbance | relocation, depth_dropout, dual_depth_dropout | Recoverable / unrecoverable conditions |
| Instruction | literal, metaphor, ambiguous | Semantic complexity / safe abstention |
| Coordinator | fixed, rule, random, trained, untrained | Mechanistic learning ablation |
| Reasoner (optional) | L1, always L2, always L3, selective hybrid | Invocation and competence comparison |
| Repeat | independent training seed set | Unit for paired training-repeat analysis |

The confirmatory `study` runner uses a matched policy×scene×disturbance×template design and freezes experience at test time. The preconfigured full study: five repetitions, 20 train seeds and eight test seeds per repeat. The 3,800 episodes include 200 training and 3,600 evaluations. The same held-out scene seeds are paired across policies **within** each repeat; distinct test seed sets are used **between** repeats.

```powershell
python robo_demo.py study --repeats 5 --train 20 --test 8 --output results/final_confirmatory
```

**Expected output:** `FINAL_REPORT.md`, `FINAL_RESULTS.json`, `protocol.json`, replicate-level `all_runs.csv`/JSON and `fig_*` plots. An existing output folder is intentionally rejected to avoid overwrites. If any infrastructure errors occur, do not claim the study succeeded.

## 5. Semantic and reasoning baselines

```powershell
python robo_demo.py semantic-benchmark --strategy l1_only --provider live
python robo_demo.py semantic-benchmark --strategy local_only --provider live
python robo_demo.py semantic-benchmark --strategy hierarchy --provider live
python robo_demo.py semantic-benchmark --strategy frontier_only --provider live --allow-openai
```

Each run is an independent semantic-only benchmark, not a full physically matched control. Frontier calls may be billable. For an integrated robot benchmark including L1 and L2:

```powershell
python robo_demo.py study --repeats 2 --train 2 --test 1 --include-reasoners --output results/reasoning_baselines
```

Add `--allow-openai` to enable L3 and paid calls. Correctness for L3 must be assessed after parser/response errors are separated from actual reasoning mistakes.

## 6. Figure and image guide

All `examples/paper_figures/` images are from experiment archives or manuscript data, and are not generated illustrations. The montage combines genuine observed frames. `publication_recoverable_failure_vs_cost.png` was drawn from the separately supplied final result totals. **No automatic screenshot is a substitute for raw sensor logs or evaluator ground truth.**

- `mujoco_viewer_tabletop.png`: overview of robot, objects and green placement target.
- `mujoco_viewer_ollama.png`: semantic-guided successful placement.
- `camera_before_relocation.png` and `camera_after_relocation.png`: RGB evidence before and after relocation.
- `camera_secondary.png`: alternative sensing viewpoint.
- `mujoco_evidence_montage.png`: example multi-view image suitable for README.
- `mujoco_colour_variation.png`: real colour conditions before/after relocation.
- `publication_recoverable_failure_vs_cost.png`: paper comparison with main failure and efficiency findings.

To acquire **new** actual frames, run a scene with `--paper-images` (if offscreen framebuffer is compatible). Alternatively, use MuJoCo's Screenshot UI while the viewer is held open. The original `main.py` saves the image filenames in each episode's `summary.json`.

## 7. Metric definitions

- **Recoverable actionable success**: correct intended target *and* completed grasp/place in relocation or primary-depth-loss case.
- **Correct ambiguity deferral**: no grasp when the instruction underdetermines the target.
- **Unrecoverable correct deferral**: no grasp when both depth sources are lost.
- **Unsupported commit**: robot grasp despite ambiguous target or mismatched intended object.
- **Nominal specialist activation**: enabled software capability logged at one decision stage. Not a CPU cycle or energy measurement.
- **Nominal graph-edge event**: logged sender–receiver dependency in an active specialist graph at one decision stage. Not a physically measured network message.
- **LLM calls/tokens**: actual provider-adapter calls and reported usage where available; parser failures may produce incomplete token counts.

## 8. Publication-valid interpretation

Across the previously reported confirmatory retry, rule and trained contextual selection were equal on recoverable task completion and nominal specialist activity, although both saved activations compared with always-on redundancy. Training outperformed the same adaptive architecture without experience, but the test does **not** demonstrate superiority over a correct hand-written rule or autonomous invention of topology. Real hardware deployment, causal learning, model uncertainty calibration and energy cost are outside this repository's demonstrated claims.

## 9. What to commit to GitHub

Commit source, tests, XML, docs, `.env.example`, selected example images, compact aggregate example and a licence chosen by the research owners. Do not commit private `.env`, actual secrets, `.venv`, logs or full experiment outputs; full 3,800-episode raw outputs should be stored as a versioned external research dataset with a checksum/DOI if publicly released. Include exact environment dependency versions and manuscript citation when ready.
