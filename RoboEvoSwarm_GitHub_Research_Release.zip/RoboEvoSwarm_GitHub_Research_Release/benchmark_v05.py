"""Matched semantic + evidence benchmark. Does not command a robot.

Usage:
  python benchmark_v05.py --strategy hierarchy --provider mock
  python benchmark_v05.py --strategy hierarchy --provider live
  python benchmark_v05.py --strategy frontier_only --provider live --allow-openai
"""
import argparse
import csv
import json
import statistics
from pathlib import Path
from roboevoswarm.reasoning import load_env, resolve_task, ollama_chat, openai_reason, Decision
from roboevoswarm.evaluation import CASES
from roboevoswarm.evidence import fixture_ledger

MOCK = {'banana':'yellow','sky':'blue','tomato':'red','sunflower':'yellow','ruby':'red'}

def fake_local(instruction):
    for k,v in MOCK.items():
        if k in instruction.lower(): return Decision(v,'ollama_mock',.9,'Offline model stub',2,85,20,'MOCK')
    return Decision(None,'ollama_mock',0,'Ambiguous',2,85,12,'MOCK')

def fake_frontier(instruction):
    for k,v in MOCK.items():
        if k in instruction.lower(): return Decision(v,'openai_mock',.9,'Offline model stub',3,95,18,'MOCK')
    return Decision(None,'openai_mock',0,'Ambiguous',3,95,15,'MOCK')

def evaluate_case(case, strategy, provider, allow_openai=False):
    local = fake_local if provider=='mock' else ollama_chat
    frontier = fake_frontier if provider=='mock' else openai_reason
    if strategy=='l1_only': mode='none'
    elif strategy=='local_only': mode='local'
    elif strategy=='frontier_only': mode='frontier'
    elif strategy=='hierarchy': mode='auto'
    else: raise ValueError(strategy)
    # Existing resolver is designed to avoid unnecessary LLMs for literal targets.
    # Always-model baselines below deliberately invoke their model, so costs differ.
    if strategy=='local_only':
        d=local(case.text); trace=[d.public_dict()]
    elif strategy=='frontier_only':
        if not allow_openai and provider=='live':
            raise ValueError('Live frontier_only requires --allow-openai')
        d=frontier(case.text); trace=[d.public_dict()]
    else:
        d,trace=resolve_task(case.text,mode=mode,allow_openai=allow_openai,
                             local_call=local,frontier_call=frontier)
    # An LLM's self-reported confidence does not override a contradictory or
    # expired evidence record. This gate is identical in all baseline modes.
    ledger=fixture_ledger(case.evidence,d.color or 'blue')
    evidence=ledger.evaluate('target','colour',now=10.)
    blocked=evidence['status']!='fresh'
    # For literal tasks, a valid decision is enough. Unknown semantic requests
    # cannot commit without semantic resolution; ambiguous candidates are audited.
    proposed=d.color if not blocked else None
    expected=case.expected or None
    correct=proposed==expected
    unsafe=expected is None and proposed is not None
    return {'id':case.id,'family':case.family,'instruction':case.text,
            'strategy':strategy,'provider':provider,'expected':expected,
            'proposed':d.color,'committed':proposed,'correct':correct,
            'unsafe_commit':unsafe,'evidence_status':evidence['status'],
            'llm_calls':sum(x.get('source') in ('ollama','openai','ollama_mock','openai_mock') for x in trace),
            'latency_ms':round(sum(float(x.get('latency_ms',0)) for x in trace),2),
            'input_tokens':sum(int(x.get('input_tokens',0)) for x in trace),
            'output_tokens':sum(int(x.get('output_tokens',0)) for x in trace),
            'trace':trace}

def run(strategy,provider,output,allow_openai=False):
    rows=[evaluate_case(c,strategy,provider,allow_openai) for c in CASES]
    summary={'strategy':strategy,'provider':provider,'n':len(rows),
             'correct':sum(x['correct'] for x in rows),
             'correct_rate':round(sum(x['correct'] for x in rows)/len(rows),4),
             'unsafe_commits':sum(x['unsafe_commit'] for x in rows),
             'llm_calls':sum(x['llm_calls'] for x in rows),
             'input_tokens':sum(x['input_tokens'] for x in rows),
             'output_tokens':sum(x['output_tokens'] for x in rows),
             'total_llm_latency_ms':round(sum(x['latency_ms'] for x in rows),2)}
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    (out/f'{strategy}_{provider}.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2),encoding='utf-8')
    with (out/f'{strategy}_{provider}.csv').open('w',newline='',encoding='utf-8') as fp:
        keys=['id','family','expected','proposed','committed','correct','unsafe_commit','evidence_status','llm_calls','latency_ms','input_tokens','output_tokens']
        writer=csv.DictWriter(fp,fieldnames=keys);writer.writeheader();writer.writerows({k:r[k] for k in keys} for r in rows)
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--strategy',choices=['l1_only','local_only','frontier_only','hierarchy'],default='hierarchy')
    p.add_argument('--provider',choices=['mock','live'],default='mock')
    p.add_argument('--allow-openai',action='store_true')
    p.add_argument('--env-file',default='.env')
    p.add_argument('--output',default='results/benchmark_v05')
    a=p.parse_args();load_env(a.env_file)
    print(json.dumps(run(a.strategy,a.provider,a.output,a.allow_openai),indent=2))

if __name__=='__main__': main()
