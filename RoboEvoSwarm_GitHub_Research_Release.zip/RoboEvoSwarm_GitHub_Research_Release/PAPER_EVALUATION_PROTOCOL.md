# RoboEvoSwarm: final confirmatory experimental protocol (ready for Methods section)

## Aim and research claims

Evaluate whether a heterogeneous, evidence-gated embodied system can (a) improve completion of instruction-conditioned tasks under recoverable depth outages; (b) reduce nominal specialist coordination activity without sacrificing physical correctness; and (c) select recovery specialists through experience beyond what an explicit reactive rule already achieves. All relevant results, including null effects and failures, are retained.

## Manipulation system

MuJoCo simulated 3-DOF tabletop arm; colour-classical RGB object segmentation and depth backprojection; a time-indexed World Model with evidence invalidation; fixed geometric manipulation with a simplified weld grasp. The first camera's post-relocation depth can fail; a second configured RGB-D camera may be invoked. Semantic interpretation may use deterministic rules, Qwen2.5:7B through Ollama and optional OpenAI via bounded structured-output routing. Raw motor commands never originate from LLM proposals.

## Five primary coordination conditions

- **Fixed redundant hybrid** activates redundant optional specialists by default and uses the same bounded semantic hierarchy as the learned model.
- **Deterministic event-triggered rule hybrid** uses lean specialists by default, then activates the second RGB-D camera when primary depth is missing; no experience learning.
- **Random hybrid** selects lean or redundant compositions from a deterministic outcome-independent pseudo-random stream keyed to scene and event, without learning.
- **Trained adaptive hybrid** uses its saved contextual-bandit experience for lean/redundant selection and freezes updates before the held-out scenes.
- **Untrained adaptive hybrid** uses identical architecture with empty frozen experience.

Optional semantic-only routing contrasts: L1 rules alone, always L2 Ollama, always L3 OpenAI; these are evaluated on matched embodied scenes if enabled. All methods retain common low-level safety and controller layers.

## Independent units, splits and prevention of leakage

Use 5 training repetitions. Each train repetition uses its own set of 20 standard scene seeds, each with two known disturbances and a literal instruction (40 training episodes). Held-out evaluation uses eight fresh scene seeds per repetition in two scene families (standard and shifted) and three disturbances × three instruction templates. Held-out seeds change across repetitions, and no test feedback updates the saved experience. Intended target and ground truth are evaluator-only and never used to replace camera observations. Do not count all episodes as statistically independent training repetitions.

## Disturbances and safety endpoints

- **Relocation:** observed object's position changes after an initial camera observation; the system receives an event notification and needs fresh perception.
- **Recoverable primary-depth dropout:** camera A loses depth after relocation; camera B remains available when selected. Correct result is physical task completion.
- **Previously unseen dual-depth dropout:** cameras A and B lose depth simultaneously. Correct result is safe deferral without grasp. This condition is *not* a recoverable task and must not be put in the actionable-completion denominator.
- **Ambiguous instruction:** target identity is underspecified. Correct result is abstention without physical manipulation, independent of disturbance condition.
- **Shifted family:** a different object-position distribution and random-number stream. It is a modest geometric distribution shift, **not an open-world robotics benchmark**.

## Primary and secondary endpoints

1. **Recoverable actionable end-to-end completion:** semantic correctness and successful grasp/place, across the two recoverable disturbances and two actionable instruction templates, reported by scene family.
2. **Ambiguity safety:** fraction of underspecified tasks safely deferred without physical action.
3. **Unrecoverable safety:** fraction of dual-depth outages safely deferred without physical action (actionable instructions only).
4. **Coordination cost:** mean *nominal* specialist activation and graph-edge-event count over matched cases, compared at non-inferior task success.
5. **Recovery mechanism:** actual camera B invocation counts from the camera-source record and successful recovery by fault type.
6. **Reasoning expenditure:** observed Ollama/OpenAI call counts and tokens. Do not estimate real API spend without published price and appropriate usage accounting.
7. **Experience adaptation:** paired changes between trained, untrained, rule and fixed baselines; per-context learned utilities and usage can be extracted from saved experience and trace.

## Planned statistical interpretation

Compute within-repetition paired differences on identical cases, and summarise across five independently trained models (means and SDs). Show per-family and per-disturbance rates and raw failure case IDs. Avoid overstating precision: small numbers of training repetitions, dependent cases within a replicate, and deterministic scripting remain limitations. A success tie with the rule baseline is a **negative result for a claim of unique learning superiority**, even if learned outperforms untrained. Do not interpret safe deferral as physical success on a recoverable task. Do not equate nominal activation/edges with energy consumption.

## Figures and tables for manuscript

- Figure 1. EvoSwarm agent graph, World Model, sensor and inference routing, clearly distinguishing fixed capabilities from learned *selection*.
- Figure 2. Actual MuJoCo environment screenshots: initial scene; relocation; primary depth outage with secondary camera recovery; dual outage with safe deferral (capture manually if needed).
- Figure 3. Recoverable success rates per policy and scene family with proper denominators.
- Figure 4. Mean nominal agent activations across policies, shown alongside success-rate constraints.
- Figure 5. Variation across independent training seeds and learned per-context preferences. Note if identical.
- Figure 6. L1–L2–L3 instruction cost and end-to-end correctness, in a separately identified matched reasoning comparison.
- Table 1. Conditions, scene seed splits, sensor failure injections, and scoring rules.
- Table 2. Per-policy completion, abstention, unsupported physical actions and infrastructure errors.
- Table 3. Ablations vs fixed redundancy, rule-based event trigger, random and untrained variants.

## Precommitted reporting rule

The paper proceeds after this single final confirmatory study using the *observed* outcomes. If the learned method does not outperform the rule comparator, narrow the claimed novelty to robust heterogeneous integration and selective activation, and present the rule as the stronger baseline. Do not launch further opportunistic studies merely to improve significance; scope limitations explicitly in the Discussion. Never publish mock software tests as robotic outcomes.
