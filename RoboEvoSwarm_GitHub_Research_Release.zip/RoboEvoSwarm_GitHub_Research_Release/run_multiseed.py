"""Independent training repeats, matched held-out scenes, paired ablation summaries.

This is a sequential orchestration. Live Ollama/OpenAI calls are made when
requested. No fabricated results, no reruns into existing result directories.
"""
from __future__ import annotations
import argparse, csv, json, subprocess, sys
from pathlib import Path
from statistics import mean, stdev


def paired_analysis(rows):
    grouped={}
    for r in rows:
        if r.get('split')!='test':continue
        grouped[(r['policy'], r['case_id'])]=r
    names=('fixed_hybrid','adaptive_hybrid','adaptive_untrained')
    keys=sorted({k[1] for k in grouped if k[0]=='adaptive_hybrid'})
    by_policy={name:[grouped[(name,c)] for c in keys if (name,c) in grouped] for name in names}
    out={'matched_test_cases':len(keys),'by_policy':{},'paired_differences':{}}
    for name,rs in by_policy.items():
        if not rs:continue
        action=[r for r in rs if not r['expected_deferral']]
        out['by_policy'][name]={
            'n':len(rs), 'actionable_n':len(action),
            'actionable_success_rate':mean(bool(r.get('end_to_end_success')) for r in action) if action else None,
            'mean_activations':mean(float(r.get('agent_activations') or 0) for r in rs),
            'nominal_graph_edges':mean(float(r.get('nominal_graph_edges') or 0) for r in rs),
            'correct_deferrals':sum(bool(r.get('correct_deferral')) for r in rs),
            'provider_errors':sum(bool((r.get('semantic_decision') or {}).get('error')) for r in rs)
        }
    for other in ('fixed_hybrid','adaptive_untrained'):
        common=[c for c in keys if ('adaptive_hybrid',c) in grouped and (other,c) in grouped]
        if not common:continue
        action=[c for c in common if not grouped[('adaptive_hybrid',c)]['expected_deferral']]
        out['paired_differences']['trained_minus_'+other]={
            'n_matched':len(common),
            'delta_success_rate':mean(int(bool(grouped[('adaptive_hybrid',c)].get('end_to_end_success')))-int(bool(grouped[(other,c)].get('end_to_end_success'))) for c in action) if action else None,
            'delta_mean_activations':mean(float(grouped[('adaptive_hybrid',c)].get('agent_activations') or 0)-float(grouped[(other,c)].get('agent_activations') or 0) for c in common),
            'delta_mean_edges':mean(float(grouped[('adaptive_hybrid',c)].get('nominal_graph_edges') or 0)-float(grouped[(other,c)].get('nominal_graph_edges') or 0) for c in common),
        }
    return out


def aggregate_repeats(reps):
    k=['delta_success_rate','delta_mean_activations','delta_mean_edges']
    results={}
    for contrast in ('trained_minus_fixed_hybrid','trained_minus_adaptive_untrained'):
        group=[r['paired_differences'][contrast] for r in reps if contrast in r['paired_differences']]
        if not group:continue
        results[contrast]={'independent_training_repeats':len(group)}
        for metric in k:
            v=[r[metric] for r in group if r.get(metric) is not None]
            results[contrast][metric]={'mean':mean(v) if v else None,
                                       'sample_sd':stdev(v) if len(v)>1 else None,
                                       'values':v}
    return results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repeats',type=int,default=3)
    parser.add_argument('--train',type=int,default=20)
    parser.add_argument('--test',type=int,default=30)
    parser.add_argument('--output',default='results/multiseed_01')
    parser.add_argument('--allow-openai',action='store_true')
    parser.add_argument('--policies',default='fixed_hybrid,adaptive_hybrid,adaptive_untrained',
                        help='Matched policies to evaluate. Add l1_only,l2_only,l3_only if needed.')
    args=parser.parse_args()
    if args.repeats<2 or args.train<1 or args.test<1: parser.error('Use >=2 training repeats, >=1 train and test scenes')
    root=Path(args.output).resolve()
    if root.exists():raise FileExistsError(f'Existing experiment directory: {root}')
    root.mkdir(parents=True)
    (root/'protocol.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    summaries=[]
    project=Path(__file__).resolve().parent
    for i in range(args.repeats):
        out=root/f'replicate_{i+1:03}'
        cmd=[sys.executable,str(project/'run_integrated.py'),'--train',str(args.train),
             '--test',str(args.test),'--train-seed-offset',str(1000*i),
             '--test-seed-offset','50000','--include-untrained','--policies',args.policies,
             '--output',str(out)]
        if args.allow_openai:cmd.append('--allow-openai')
        result=subprocess.run(cmd,cwd=project)
        if result.returncode:raise RuntimeError(f'Replicate {i+1} failed (exit {result.returncode}); inspect {out}')
        rows=json.loads((out/'all_runs.json').read_text(encoding='utf-8'))
        summary=paired_analysis(rows)
        summary['replicate']=i+1
        summary['train_seed_offset']=1000*i
        summaries.append(summary)
        (out/'ABLATION.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    stats=aggregate_repeats(summaries)
    (root/'MULTISEED.json').write_text(json.dumps({'replicates':summaries,'across_training_repeats':stats},indent=2),encoding='utf-8')
    lines=['# RoboEvoSwarm v0.7.1 — paired multi-seed ablation','',
           f'Independent training repetitions: {args.repeats}; training scenes per repeat: {args.train}; matched held-out test scenes: {args.test}.',
           'Actionable successes exclude intentionally ambiguous tasks. All failure cases remain in the denominator.',
           'Each repeat trains its own experience; untrained ablation receives a fresh empty experience table and frozen evaluation.',
           'The test scene seeds are identical across repeats; the training seeds differ. Uncertainty must be assessed at the training-repeat level.', '',
           '| Comparison (trained minus baseline) | Mean Δ actionable success | Mean Δ activations | Mean Δ nominal edges |',
           '|---|---:|---:|---:|']
    for contrast,v in stats.items():
        def fmt(metric):
            a=v[metric];return 'N/A' if a['mean'] is None else f"{a['mean']:+.4f} (SD {a['sample_sd']:.4f})" if a['sample_sd'] is not None else f"{a['mean']:+.4f}"
        lines.append(f"| {contrast} | {fmt('delta_success_rate')} | {fmt('delta_mean_activations')} | {fmt('delta_mean_edges')} |")
    lines+=['','## Interpretation caveats','',
            '- The bandit only chooses from predefined specialist compositions; graph invention is not tested.',
            '- A trained policy advantage requires a meaningful positive paired result, not merely a low activation count.',
            '- LLM responses are separately invoked for each policy; model nondeterminism can affect comparisons.',
            '- No evidence from this output supports a timing or actual energy-consumption claim.','']
    (root/'MULTISEED_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines))

if __name__=='__main__':main()
