"""Bounded, auditable semantic reasoning for robot task selection.

LLM output is only a *proposal* for a colour identifier from the known scene.
It can never prescribe unvalidated motion or physical commands.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from pathlib import Path
import json
import os
import re
import time
import urllib.error
import urllib.request

COLORS = ('red', 'blue', 'yellow')
SYSTEM = ("You interpret requests for a tabletop robot. Choose exactly one target colour "
          "from red, blue, yellow only if the request uniquely specifies it. "
          "If uncertain or ambiguous, return null. Output only a JSON object with keys "
          "color (string or null), confidence (0 to 1), and reason (short string). "
          "You are not permitted to plan motions, bypass safety checks, or invent object positions.")


@dataclass
class Decision:
    color: str | None
    source: str
    confidence: float
    reason: str
    latency_ms: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ''
    error: str | None = None

    def public_dict(self):
        return asdict(self)


def load_env(path='.env'):
    """Optional dotenv with no dependency. Never overwrite existing OS env vars."""
    f=Path(path)
    if not f.exists():
        return
    for line in f.read_text(encoding='utf-8-sig').splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        key,value=line.split('=',1)
        key=key.strip(); value=value.strip().strip('\"').strip("'")
        if re.fullmatch(r'[A-Z_][A-Z0-9_]*',key): os.environ.setdefault(key,value)


def structured_colour(instruction):
    """Only unambiguous literal colour words. Synonyms remain a semantic problem."""
    words=set(re.findall(r'\b[a-z]+\b', instruction.lower()))
    found=[c for c in COLORS if c in words]
    if len(found)==1:
        return Decision(found[0],'structured',1.0,'Explicit unique colour in instruction')
    if len(found)>1:
        return Decision(None,'ambiguous',0.0,'Multiple colours referenced: requires clarification')
    return None


def parse_proposal(raw):
    """Strict JSON-only parser; reject any extra text or fabricated choices."""
    data=json.loads(raw.strip())
    if not isinstance(data,dict): raise ValueError('Proposal must be JSON object')
    c=data.get('color')
    if c is not None and (not isinstance(c,str) or c not in COLORS):
        raise ValueError('Unsupported target colour')
    confidence=float(data.get('confidence',0))
    if not 0<=confidence<=1: raise ValueError('Invalid confidence')
    reason=str(data.get('reason',''))[:220]
    if c is not None and confidence < .65: return None,confidence,'Low confidence: '+reason
    return c,confidence,reason


def ollama_chat(instruction, *, model=None, url=None, timeout=None, transport=None):
    model=model or os.environ.get('OLLAMA_MODEL','qwen2.5:7b')
    url=(url or os.environ.get('OLLAMA_BASE_URL','http://127.0.0.1:11434')).rstrip('/')
    timeout=float(timeout or os.environ.get('LLM_TIMEOUT_SECONDS','90'))
    payload={'model':model,'stream':False,'format':'json','options':{'temperature':0,'num_predict':160},
             'messages':[{'role':'system','content':SYSTEM},
                         {'role':'user','content':'Task instruction: '+instruction+'\nKnown colours: red, blue, yellow.'}]}
    request=urllib.request.Request(url+'/api/chat',data=json.dumps(payload).encode(),
                                   headers={'Content-Type':'application/json'},method='POST')
    started=time.perf_counter()
    try:
        if transport is None:
            with urllib.request.urlopen(request,timeout=timeout) as response: data=json.load(response)
        else: data=transport(request, timeout)
        if not isinstance(data,dict): raise ValueError('Ollama response not an object')
        output=data.get('message',{}).get('content','')
        colour,confidence,reason=parse_proposal(output)
        return Decision(colour,'ollama',confidence,reason,round((time.perf_counter()-started)*1000,2),
                        int(data.get('prompt_eval_count') or 0),int(data.get('eval_count') or 0),model)
    except (urllib.error.URLError,TimeoutError,OSError,ValueError,KeyError,TypeError, json.JSONDecodeError) as e:
        return Decision(None,'ollama',0.,'No trustworthy semantic decision',round((time.perf_counter()-started)*1000,2),
                        model=model,error=type(e).__name__+': '+str(e)[:180])


OPENAI_TARGET_SCHEMA = {
    'type': 'object',
    'properties': {
        'color': {'type': ['string', 'null'], 'enum': ['red', 'blue', 'yellow', None]},
        'confidence': {'type': 'number'},
        'reason': {'type': 'string'},
    },
    'required': ['color', 'confidence', 'reason'],
    'additionalProperties': False,
}


def openai_reason(instruction, *, model=None, client=None):
    """Schema-constrained OpenAI Responses API; preserve usage on parse errors.

    Failed/empty/incomplete responses are *not* counted as valid refusals.
    A non-null target remains subject to downstream evidence validation.
    """
    model = model or os.environ.get('OPENAI_MODEL', 'gpt-4.1-mini')
    started = time.perf_counter()
    if not os.environ.get('OPENAI_API_KEY') and client is None:
        return Decision(None,'openai',0.,'API key missing',model=model,error='Missing OPENAI_API_KEY')
    usage_in=usage_out=0
    status='unavailable'
    try:
        if client is None:
            from openai import OpenAI
            client=OpenAI(timeout=float(os.environ.get('LLM_TIMEOUT_SECONDS','90')),max_retries=0)
        response=client.responses.create(
            model=model, instructions=SYSTEM,
            input='Task instruction: '+instruction+'\nKnown colours: red, blue, yellow.',
            text={'format': {'type':'json_schema','name':'robot_target',
                             'strict':True,'schema':OPENAI_TARGET_SCHEMA}},
            max_output_tokens=512,
        )
        usage=getattr(response,'usage',None)
        usage_in=int(getattr(usage,'input_tokens',0) or 0)
        usage_out=int(getattr(usage,'output_tokens',0) or 0)
        status=str(getattr(response,'status','completed'))
        if status not in ('completed','None'):
            detail=getattr(response,'incomplete_details',None) or getattr(response,'error',None)
            raise ValueError(f'Response status={status}; detail={detail}')
        raw=getattr(response,'output_text',None)
        if not isinstance(raw,str) or not raw.strip():
            raise ValueError(f'Empty output_text; response status={status}')
        colour,confidence,reason=parse_proposal(raw)
        return Decision(colour,'openai',confidence,reason,
                        round((time.perf_counter()-started)*1000,2),usage_in,usage_out,model)
    except Exception as e:
        return Decision(None,'openai',0.,'No trustworthy semantic decision',
                        round((time.perf_counter()-started)*1000,2),usage_in,usage_out,model,
                        error=f'{type(e).__name__}: {str(e)[:250]} [status={status}]')


def resolve_task(instruction, *, mode='auto', allow_openai=False, local_call=ollama_chat, frontier_call=openai_reason):
    """No OpenAI charge without both explicit permission and permitted mode.

    An LLM proposal cannot override a unique explicit colour. Ambiguity is
    treated conservatively and requires a subsequent human clarification.
    """
    if mode not in ('none','local','auto','frontier'): raise ValueError('Invalid llm mode')
    literal=structured_colour(instruction)
    if literal: return literal, [literal.public_dict()]
    trace=[]
    if mode=='none':
        return Decision(None,'none',0.,'No literal target; reasoning disabled'),trace
    if mode in ('auto','local'):
        d=local_call(instruction)
        trace.append(d.public_dict())
        if d.color is not None: return d,trace
    if mode in ('auto','frontier') and allow_openai:
        d=frontier_call(instruction)
        trace.append(d.public_dict())
        if d.color is not None: return d,trace
    return Decision(None,'deferred',0.,'No sufficiently grounded unique target'),trace


def resolve_policy(instruction, policy, *, allow_openai=False,
                   local_call=None, frontier_call=None):
    """Explicitly separate always-model baselines from selective hierarchy.

    Model output is a bounded *proposal*; safety and physics remain in L1.
    """
    if local_call is None: local_call=ollama_chat
    if frontier_call is None: frontier_call=openai_reason
    if policy in ('l1_only',):
        d=structured_colour(instruction)
        return (d, [d.public_dict()]) if d else (Decision(None,'none',0.,'L1 cannot resolve nonliteral request'), [])
    if policy=='l2_only':
        d=local_call(instruction)
        return d,[d.public_dict()]
    if policy=='l3_only':
        if not allow_openai:
            raise ValueError('l3_only requires explicit --allow-openai')
        d=frontier_call(instruction)
        return d,[d.public_dict()]
    if policy in ('fixed_hybrid','adaptive_hybrid'):
        return resolve_task(instruction, mode='auto', allow_openai=allow_openai,
                            local_call=local_call, frontier_call=frontier_call)
    raise ValueError('Unknown semantic policy: '+str(policy))
