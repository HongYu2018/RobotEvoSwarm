from __future__ import annotations
from pathlib import Path
import time
import numpy as np
import mujoco

SCENE = Path(__file__).resolve().parent.parent / 'assets' / 'laboratory.xml'


class Laboratory:
    """3-DOF arm controlled by MuJoCo position servos and model-based numerical IK."""

    def __init__(self):
        self.playback_speed = 1.0
        self.model = mujoco.MjModel.from_xml_path(str(SCENE))
        self.data = mujoco.MjData(self.model)
        self.ik_data = mujoco.MjData(self.model)  # Independent calculations; never teleport real simulation.
        self.tip_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, 'tool_tip')
        self.tool_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, 'tool_body')
        self.block_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, 'blue_block')
        self.selected_block = 'blue_block'
        self.weld_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_EQUALITY, 'grasp_blue_block')
        self.joint_ids = [mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, n)
                          for n in ('yaw', 'shoulder', 'elbow')]
        self.qpos_ids = np.array([int(self.model.jnt_qposadr[j]) for j in self.joint_ids])
        self.dof_ids = np.array([int(self.model.jnt_dofadr[j]) for j in self.joint_ids])
        self.limits = np.array([self.model.jnt_range[j] for j in self.joint_ids])
        mujoco.mj_forward(self.model, self.data)

    @property
    def t(self):
        return float(self.data.time)

    @property
    def tip(self):
        return self.data.site_xpos[self.tip_id].copy()

    @property
    def block(self):
        return self.data.xpos[self.block_id].copy()

    def inverse_kinematics(self, xyz, tolerance=0.003, max_iter=250):
        """Damped least-squares IK using the actual tool-tip position and Jacobian.

        The scene has exactly three actuated hinge joints. IK runs on separate MjData;
        only joint targets are sent to the simulated servos.
        """
        target = np.asarray(xyz, dtype=float)
        if target.shape != (3,) or not np.all(np.isfinite(target)):
            raise ValueError(f'Invalid XYZ target: {xyz}')
        # Multiple seeds help avoid a poor local joint configuration.
        current = self.data.qpos[self.qpos_ids].copy()
        seeds = [current, np.array([np.arctan2(target[1], target[0]), 0.7, 1.4]),
                 np.array([np.arctan2(target[1], target[0]), 1.5, -1.4]),
                 np.array([np.arctan2(target[1], target[0]), -0.3, 1.8])]
        best_q, best_error = None, float('inf')
        Jp = np.zeros((3, self.model.nv))
        Jr = np.zeros((3, self.model.nv))
        for seed in seeds:
            q = np.clip(seed, self.limits[:, 0] + 1e-3, self.limits[:, 1] - 1e-3)
            for _ in range(max_iter):
                self.ik_data.qpos[:] = self.data.qpos
                self.ik_data.qpos[self.qpos_ids] = q
                mujoco.mj_forward(self.model, self.ik_data)
                err = target - self.ik_data.site_xpos[self.tip_id]
                dist = float(np.linalg.norm(err))
                if dist < best_error:
                    best_error, best_q = dist, q.copy()
                if dist <= tolerance:
                    return q
                mujoco.mj_jacSite(self.model, self.ik_data, Jp, Jr, self.tip_id)
                J = Jp[:, self.dof_ids]
                damping = 0.015
                dq = J.T @ np.linalg.solve(J @ J.T + damping**2 * np.eye(3), err)
                q = np.clip(q + np.clip(dq, -0.11, 0.11),
                            self.limits[:, 0] + 1e-3, self.limits[:, 1] - 1e-3)
        if best_error > 0.015:
            raise ValueError(f'IK target cannot be reached: {target.tolist()}, '
                             f'best geometric tip error={best_error:.3f}m')
        return best_q

    def _move_joints(self, target, duration, viewer=None):
        """Simulated position-servo motion with smooth command interpolation."""
        target = np.asarray(target, dtype=float)
        initial = self.data.ctrl.copy()
        steps = max(1, int(duration / self.model.opt.timestep))
        wall_start = time.perf_counter()
        for k in range(steps):
            u = min(1.0, (k + 1) / max(1, round(steps * .60)))
            alpha = u * u * (3 - 2 * u)
            self.data.ctrl[:] = initial * (1 - alpha) + target * alpha
            mujoco.mj_step(self.model, self.data)
            if viewer is not None and (k % 10 == 0 or k == steps - 1):
                viewer.sync()
                # Pace simulation against wall-clock so the movement is watchable.
                target_wall_time = (k + 1) * self.model.opt.timestep / self.playback_speed
                delay = target_wall_time - (time.perf_counter() - wall_start)
                if delay > 0:
                    time.sleep(delay)

    def diagnostics(self):
        """Report physics contacts and torques without access to hidden task results."""
        contacts = []
        for k in range(self.data.ncon):
            c = self.data.contact[k]
            name1 = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_GEOM, c.geom1)
            name2 = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_GEOM, c.geom2)
            contacts.append(f"{name1 or c.geom1} / {name2 or c.geom2}: gap={c.dist:.4f}m")
        return (f"qpos={np.round(self.data.qpos[self.qpos_ids], 3)}, "
                f"ctrl={np.round(self.data.ctrl, 3)}, "
                f"actuator_torques={np.round(self.data.qfrc_actuator[self.dof_ids], 2)}, "
                f"contacts={contacts[:12]}")

    def step_to(self, xyz, duration=4.0, viewer=None, tolerance=0.045):
        """Collision-conscious staged movement: retract, rotate yaw, then extend.

        A bent 3-DOF arm can intersect the table if its yaw changes while
        extended. Retraction provides a simple, inspectable transit policy.
        It does not replace collision-aware planning for real robots.
        """
        target = self.inverse_kinematics(xyz)
        current = self.data.qpos[self.qpos_ids].copy()
        yaw_delta = abs(float(target[0] - current[0]))
        if yaw_delta > 0.07:
            # Return the arm to a compact upright pose before horizontal rotation.
            self._move_joints([current[0], 0., 0.], 2.0, viewer)
            # Yaw while the two main links are approximately upright.
            self._move_joints([target[0], 0., 0.], 2.5, viewer)
            yaw_err = abs(float(self.data.qpos[self.qpos_ids[0]] - target[0]))
            if yaw_err > 0.075:
                raise RuntimeError(
                    f"Yaw failed while arm was retracted: requested={target[0]:.3f}, "
                    f"actual={self.data.qpos[self.qpos_ids[0]]:.3f}, "
                    f"error={yaw_err:.3f}rad; {self.diagnostics()}. "
                    "This indicates actuation/contact trouble, not a Cartesian IK error.")
        self._move_joints(target, max(3.5, duration), viewer)
        error = float(np.linalg.norm(self.tip - np.asarray(xyz, dtype=float)))
        if error > tolerance:
            raise RuntimeError(
                f"Waypoint execution failed: goal={np.round(xyz,3)}, "
                f"tip={np.round(self.tip,3)}, error={error:.3f}m; "
                f"joint_target={np.round(target,3)}; {self.diagnostics()}")
        return error

    def choose_object(self, name):
        if name not in ('red_block', 'blue_block', 'yellow_block'):
            raise ValueError('Unknown object: ' + name)
        self.selected_block = name
        self.block_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, name)
        self.weld_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_EQUALITY, 'grasp_' + name)
        mujoco.mj_forward(self.model, self.data)

    def object_position(self, name):
        i = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, name)
        return self.data.xpos[i].copy()

    def relocate_object(self, name, xyz):
        """Declared external intervention; not a robot movement. Reset velocities."""
        joint = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name + '_free')
        qa = int(self.model.jnt_qposadr[joint])
        da = int(self.model.jnt_dofadr[joint])
        self.data.qpos[qa:qa+3] = xyz
        self.data.qpos[qa+3:qa+7] = (1, 0, 0, 0)
        self.data.qvel[da:da+6] = 0
        mujoco.mj_forward(self.model, self.data)

    def grasp(self, max_distance=0.085):
        """Attach block to tool at measured relative pose (simplified weld grasp)."""
        distance = float(np.linalg.norm(self.tip - self.block))
        if distance > max_distance:
            return False, distance
        d = self.data
        p1, p2 = d.xpos[self.tool_id], d.xpos[self.block_id]
        r1 = d.xmat[self.tool_id].reshape(3, 3)
        r2 = d.xmat[self.block_id].reshape(3, 3)
        rel_pos = r1.T @ (p2 - p1)
        rel_rot = r1.T @ r2
        rel_quat = np.zeros(4)
        mujoco.mju_mat2Quat(rel_quat, rel_rot.reshape(-1))
        # MuJoCo weld eq_data layout (v3/v4):
        #   [0:3]   anchor (NOT the relative position)
        #   [3:6]   body2 position expressed in body1 frame
        #   [6:10]  body2 orientation expressed in body1 frame (w,x,y,z)
        #   [10]    torque scale
        #   [11]    compiler flag for default/reference relative pose (v4)
        # Older code incorrectly wrote rel_pos to [0:3] and rel_quat
        # to [3:7], creating a radically wrong constraint target.
        self.model.eq_data[self.weld_id, 3:6] = rel_pos
        self.model.eq_data[self.weld_id, 6:10] = rel_quat
        if self.model.eq_data.shape[1] > 11:
            self.model.eq_data[self.weld_id, 11] = 0  # explicit live relpose
        d.eq_active[self.weld_id] = 1
        mujoco.mj_forward(self.model, d)
        return True, distance

    def release(self):
        self.data.eq_active[self.weld_id] = 0

    def block_tool_distance(self):
        """Simple grasp-health check for the temporary weld-based prototype."""
        return float(np.linalg.norm(self.tip - self.block))
