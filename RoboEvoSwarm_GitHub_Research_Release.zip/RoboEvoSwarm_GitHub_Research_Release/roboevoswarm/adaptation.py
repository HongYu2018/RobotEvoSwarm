"""Experience-driven contextual selection among safe capability compositions.

This is a small tabular contextual bandit, NOT neural learning or autonomous
creation of novel physical skills. All safety / motion requirements are protected.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import json
from pathlib import Path

MANDATORY = {'sense': ('rgbd_perception',), 'verify': ('evidence_gate',),
             'plan': ('motion_planner', 'safety'), 'execute': ('manipulation', 'safety'),
             'audit': ('outcome_audit',), 'recover': ('evidence_gate',)}
OPTIONAL = {'sense': 'depth_crosscheck', 'verify': 'reobservation',
            'plan': 'geometric_recheck', 'recover': 'second_rgbd_camera'}

@dataclass
class Experience:
    records: dict = field(default_factory=dict)

    def choose(self, context, options=('lean', 'redundant')):
        scores = self.records.get(context, {})
        # Deterministic two-action exploration: evaluate each choice at least
        # once per context, then reuse the higher observed mean reward.
        # This is a small empirical bandit, not a theoretical regret guarantee.
        for action in options:
            if action not in scores:
                return action
        return max(options, key=lambda a: (scores[a]['value'], a == 'lean'))

    def update(self, context, action, reward):
        row = self.records.setdefault(context, {}).setdefault(action, {'n': 0, 'value': 0.0})
        row['n'] += 1
        row['value'] += (float(reward) - row['value']) / row['n']

    def save(self, path):
        Path(path).write_text(json.dumps(self.records, indent=2), encoding='utf-8')

    @classmethod
    def load(cls, path):
        p = Path(path)
        return cls(json.loads(p.read_text(encoding='utf-8'))) if p.exists() else cls()

class ContextualSelector:
    def __init__(self, mode, experience=None, random_seed=0):
        if mode not in ('learned', 'reactive_fixed', 'lean_fixed', 'rule_fixed', 'random_fixed'):
            raise ValueError(mode)
        self.mode, self.experience = mode, experience or Experience()
        self.random_seed = random_seed
        self.trace = []

    def select(self, stage, condition, t):
        context = f'{stage}:{condition}'
        if self.mode == 'reactive_fixed':
            action = 'redundant'
        elif self.mode == 'lean_fixed':
            action = 'lean'
        elif self.mode == 'rule_fixed':
            action = 'redundant' if stage == 'recover' and condition == 'primary_depth_missing' else 'lean'
        elif self.mode == 'random_fixed':
            # Deterministic hash, stable across processes and independent of test outcome.
            import hashlib
            h = hashlib.sha256(f'{self.random_seed}:{len(self.trace)}:{context}'.encode()).digest()
            action = 'redundant' if h[0] < 128 else 'lean'
        else:
            action = self.experience.choose(context)
        agents = list(MANDATORY[stage])
        if action == 'redundant' and stage in OPTIONAL:
            agents.append(OPTIONAL[stage])
        row = {'t': round(float(t), 3), 'stage': stage, 'condition': condition,
               'context': context, 'action': action, 'agents': agents,
               'edges': [[a,b] for a,b in zip(agents, agents[1:])]}
        self.trace.append(row)
        return row

    def learn(self, success):
        # Outcome-based update; expensive redundant specialists are penalised
        # while unsuccessful lean options receive a stronger negative reward.
        if self.mode != 'learned':
            return
        for row in self.trace:
            extra_cost = (row['action'] == 'redundant')
            reward = (1.0 if success else -1.0) - (0.12 if extra_cost else 0.0)
            self.experience.update(row['context'], row['action'], reward)
