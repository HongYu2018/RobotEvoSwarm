"""Inspectably simple EvoSwarm-v0.2 orchestration and evidence semantics.

NOT trained visual perception or learned topology. Evaluated as a research prototype.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

COLORS = ('red', 'blue', 'yellow')
NAME = {color: color + '_block' for color in COLORS}


@dataclass
class Evidence:
    entity: str
    xyz: list[float]
    source: str
    observed_at: float
    version: int
    status: str = 'fresh'


@dataclass
class EmbodiedWorldModel:
    state: dict = field(default_factory=dict)
    history: list = field(default_factory=list)
    dynamics: dict = field(default_factory=lambda: {'object_relocation': ['pose_invalidated', 'relocalise', 'replan']})
    beliefs: dict = field(default_factory=dict)
    provenance: dict = field(default_factory=dict)
    versions: dict = field(default_factory=lambda: {c: 0 for c in COLORS})

    def log(self, t, event, **detail):
        row = {'t': round(float(t), 3), 'event': event, **detail}
        self.history.append(row)
        return row

    def observe(self, entity, xyz, timestamp, source='simulated_pose_sensor'):
        color = entity.removesuffix('_block')
        evidence = Evidence(entity, list(map(float, xyz)), source, round(float(timestamp), 3), self.versions[color])
        self.beliefs[color] = vars(evidence)
        self.state[entity] = evidence.xyz
        self.provenance[entity] = {'source': source, 'time': evidence.observed_at, 'version': evidence.version}
        self.log(timestamp, 'observation', entity=entity, xyz=evidence.xyz, source=source, version=evidence.version)
        return evidence

    def invalidate(self, color, timestamp, reason):
        self.versions[color] += 1
        if color in self.beliefs:
            self.beliefs[color]['status'] = 'stale'
        self.log(timestamp, 'evidence_invalidated', entity=NAME[color], reason=reason,
                 required_actions=self.dynamics['object_relocation'], new_version=self.versions[color])

    def fresh(self, color):
        e = self.beliefs.get(color)
        return bool(e and e['status'] == 'fresh' and e['version'] == self.versions[color])

    def task_view(self, color):
        """Task-conditioned projection: no unrelated object poses included."""
        return {'goal_color': color, 'pose': self.beliefs.get(color), 'actions': ['observe', 'plan', 'grasp', 'place'],
                'evidence_fresh': self.fresh(color)}


class SimulatedPoseSensor:
    """An explicitly oracle-backed pose sensor with rounding, NOT a trained RGB-D model.

    Simulator poses are used for this controlled intermediate step, after which
    camera RGB/depth perception can replace this adapter without changing agents.
    """
    def sense(self, lab, color, wm):
        xyz = np.round(lab.object_position(NAME[color]), 4)
        return wm.observe(NAME[color], xyz, lab.t)


class SwarmSelector:
    """Deterministic task/context-dependent graph; experience learning is future work."""
    FULL = ('perception', 'state_verification', 'planning', 'safety', 'manipulation', 'outcome_audit')

    def __init__(self, mode='adaptive'):
        if mode not in ('adaptive', 'fixed', 'reactive_fixed'):
            raise ValueError('Unknown mode')
        self.mode = mode
        self.trace = []

    def select(self, stage, t, world, task):
        if self.mode != 'adaptive':
            active = list(self.FULL)
        else:
            active = {
                'sense': ['perception'],
                'verify': ['state_verification', 'perception'] if not world.fresh(task) else ['state_verification'],
                'plan': ['planning', 'safety'],
                'execute': ['manipulation', 'safety'],
                'audit': ['outcome_audit'],
            }[stage]
        edges = [[a, b] for a, b in zip(active, active[1:])]
        row = {'t': round(float(t), 3), 'stage': stage, 'agents': active, 'edges': edges}
        self.trace.append(row)
        world.log(t, 'agent_selection', **{k: v for k, v in row.items() if k != 't'})
        return active


def pick_waypoints(xyz):
    x, y = float(xyz[0]), float(xyz[1])
    return [('approach_pick', (x, y, 0.24), 4.0),
            ('lower_to_pick', (x, y, 0.112), 4.0)]


def drop_waypoints():
    return [('lift', (0.34, -0.10, 0.24), 4.0),
            ('travel_above_target', (0.34, 0.27, 0.24), 5.0),
            ('lower_to_place', (0.34, 0.27, 0.112), 4.0)]
