"""Frozen, reproducible scene generator. Evaluator-only ground truth.

Training and test seed ranges are disjoint. Positions stay within the simple
robot's workspace, but not all possible samples are known to be reachable;
failures count as failures and must not be silently discarded.
"""
from __future__ import annotations
import numpy as np


def verify_scene_split(seed: int, split: str):
    if seed < 0: raise ValueError('scene seed must be nonnegative')
    if split not in ('train','test'): raise ValueError(split)
    # Separate PRNG streams, not just seed labels.
    return True


def scene_spec(seed: int, split: str, disturbance: str, color: str, family: str='standard'):
    verify_scene_split(seed,split)
    if family not in ('standard','shifted'): raise ValueError(family)
    if disturbance not in ('none','relocation','depth_dropout','dual_depth_dropout'): raise ValueError(disturbance)
    if color not in ('blue','red','yellow'): raise ValueError(color)
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), 0 if split=='train' else 1000003,
                                                        {'blue':1,'red':2,'yellow':3}[color], 0 if family=='standard' else 99173]))
    # The physical arm was verified near (x=.34,y=-.1). Randomisation deliberately
    # stays within a modest interval to avoid conflating research with new IK bugs.
    initial = [round(float(rng.uniform(.315,.365) if family=='standard' else rng.uniform(.335,.385)),5),round(float(rng.uniform(-.135,-.065) if family=='standard' else rng.uniform(-.175,-.095)),5),.058]
    if disturbance in ('relocation','depth_dropout','dual_depth_dropout'):
        moved = [round(float(rng.uniform(.325,.36) if family=='standard' else rng.uniform(.345,.38)),5), round(float(rng.uniform(-.15,-.075) if family=='standard' else rng.uniform(-.18,-.105)),5), .058]
        # Ensure a meaningful change so stale measurement matters.
        if abs(moved[1]-initial[1]) < .035:
            initial[1]=round(min(-.045, moved[1]+.075),5)
    else:
        moved=initial.copy()
    distractors = [[round(float(rng.uniform(.48,.52)),5),-.23,.058],
                   [round(float(rng.uniform(.48,.53)),5),.14,.058]]
    return {'distractor_poses':distractors,'seed':seed,'split':split,'family':family,'color':color,'disturbance':disturbance,
            'initial_pose':initial,'moved_pose':moved,
            'policy_observations':'camera only','ground_truth_role':'evaluator only'}
