"""Camera-only geometric localization: RGB segmentation + depth backprojection.

Simulator ground-truth body poses are NEVER used to estimate object positions.
The evaluator and robot physics may still access simulator state independently.
This is calibrated *classical* image processing, not neural object detection.
"""
from __future__ import annotations
from dataclasses import dataclass
import time
import numpy as np


@dataclass
class VisionResult:
    color: str
    xyz: list[float] | None
    confidence: float
    pixels: int
    uncertainty_m: float
    status: str
    capture_time_s: float
    runtime_ms: float
    source: str = 'mujoco_rgb_depth_color_segmentation'


def color_mask(rgb: np.ndarray, color: str) -> np.ndarray:
    """Threshold synthetic coloured blocks with illumination-tolerant ratios."""
    rgb = np.asarray(rgb, dtype=np.float32) / 255.0
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    if color == 'red':
        return (r > .25) & (r > g * 1.65) & (r > b * 1.48)
    if color == 'blue':
        return (b > .26) & (b > r * 1.40) & (b > g * 1.14)
    if color == 'yellow':
        return (r > .30) & (g > .22) & (r > b * 1.65) & (g > b * 1.5) & (r > g * .91)
    raise ValueError(color)


def backproject_pixels(uv: np.ndarray, depths: np.ndarray, cam_pos: np.ndarray,
                       cam_mat: np.ndarray, fovy_degrees: float, width: int, height: int) -> np.ndarray:
    """MuJoCo camera looks along local -Z with local +Y up; depth is metric range along viewing axis."""
    fy = height / (2 * np.tan(np.deg2rad(float(fovy_degrees)) / 2))
    fx = fy  # square pixels; fovy measured vertically
    xx = (uv[:, 0] + .5 - width / 2) * depths / fx
    yy = -(uv[:, 1] + .5 - height / 2) * depths / fy
    local = np.stack((xx, yy, -depths), axis=1)
    return np.asarray(cam_pos)[None, :] + local @ np.asarray(cam_mat).reshape(3, 3).T


def identify(rgb, depth, color, cam_pos, cam_mat, fovy, *, capture_time_s=0.0,
             minimum_pixels=12, max_samples=200):
    started = time.perf_counter()
    mask = color_mask(rgb, color)
    # Depth is from physics engine's depth renderer, not the hidden object pose.
    valid = mask & np.isfinite(depth) & (depth > .02) & (depth < 5)
    ys, xs = np.where(valid)
    n = int(len(xs))
    if n < minimum_pixels:
        return VisionResult(color, None, 0., n, float('inf'), 'missing', capture_time_s,
                            1000*(time.perf_counter()-started))
    # Backproject the colour pixels, then filter by physical workspace and
    # tabletop cube height. This is essential because the ROBOT ARM IS BLUE:
    # colour alone would incorrectly select the much larger arm instead.
    cap = 18000
    if n > cap:
        pick = np.linspace(0, n - 1, cap, dtype=int)
        xs, ys = xs[pick], ys[pick]
    uv_all = np.stack((xs, ys), axis=1).astype(float)
    z_all = np.asarray(depth)[ys, xs].astype(float)
    world_all = backproject_pixels(uv_all, z_all, cam_pos, cam_mat,
                                   fovy, rgb.shape[1], rgb.shape[0])
    on_table = ((world_all[:, 0] > .12) & (world_all[:, 0] < .70) &
                (np.abs(world_all[:, 1]) < .36) &
                (world_all[:, 2] > .034) & (world_all[:, 2] < .088))
    cloud = world_all[on_table]
    if len(cloud) < minimum_pixels:
        return VisionResult(color, None, 0., int(len(cloud)), float('inf'),
                            'missing', capture_time_s,
                            1000*(time.perf_counter()-started))
    xyz = np.median(cloud, axis=0)
    # A fitted tabletop prior sets height: surface z=0.030 and block half-height .025.
    xyz[2] = .055
    spread = np.median(np.linalg.norm(cloud[:, :2] - xyz[:2], axis=1))
    uncertainty = float(max(.008, 2 * spread))
    n = int(len(cloud))
    confidence = float(np.clip(min(1., n / 70) * np.exp(-uncertainty / .15), 0, 1))
    status = 'uncertain' if confidence < .45 or uncertainty > .055 else 'fresh'
    return VisionResult(color, [round(float(v), 4) for v in xyz], round(confidence, 3), n,
                        round(uncertainty, 4), status, capture_time_s,
                        round(1000*(time.perf_counter()-started), 3))


class RGBDObserver:
    def __init__(self, lab, width=640, height=480, camera_name="lab_camera"):
        import mujoco
        self.lab = lab
        self.camera_name = camera_name
        self.width, self.height = width, height
        self.renderer = mujoco.Renderer(lab.model, height=height, width=width)
        self.camera_id = mujoco.mj_name2id(lab.model, mujoco.mjtObj.mjOBJ_CAMERA, camera_name)

    def observe(self, color, output_prefix=None, depth_dropout=False):
        # Render RGB + depth of *the same* physics state, so timestamps align.
        self.renderer.disable_depth_rendering()
        self.renderer.update_scene(self.lab.data, camera=self.camera_name)
        rgb = self.renderer.render().copy()
        self.renderer.enable_depth_rendering()
        self.renderer.update_scene(self.lab.data, camera=self.camera_name)
        depth = self.renderer.render().copy()
        self.renderer.disable_depth_rendering()
        if depth_dropout:
            # Evaluator-controlled depth sensor outage; RGB remains an authentic MuJoCo frame.
            depth = np.zeros_like(depth)
        if output_prefix is not None:
            from PIL import Image
            Image.fromarray(rgb).save(str(output_prefix) + '_rgb.png')
            np.save(str(output_prefix) + '_depth.npy', depth)
        data, model = self.lab.data, self.lab.model
        result=identify(rgb, depth, color, data.cam_xpos[self.camera_id],
                        data.cam_xmat[self.camera_id], model.cam_fovy[self.camera_id],
                        capture_time_s=self.lab.t)
        result.source = self.camera_name + ':rgb_depth_segmentation'
        return result

    def close(self):
        self.renderer.close()
