"""Research prototype: heterogeneous robot capability orchestration."""
__version__ = "0.1.0"
