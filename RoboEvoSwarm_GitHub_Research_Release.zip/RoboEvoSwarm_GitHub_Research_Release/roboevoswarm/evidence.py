"""Small typed, temporal evidence gate for v0.5 (not probabilistic calibration).

Evidence only comes from observations or test fixtures. Human/task claims have
explicit authority and validity, while true physical positions remain hidden.
"""
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass(frozen=True)
class Claim:
    entity: str
    attribute: str
    value: str
    source: str
    captured_at: float
    expires_at: float
    version: int
    confidence: float = 1.0

class EvidenceLedger:
    def __init__(self):
        self.claims = []
        self.invalid_after = {}
        self.version = 0

    def add(self, claim: Claim):
        if not 0 <= claim.confidence <= 1: raise ValueError('confidence outside [0,1]')
        self.claims.append(claim)

    def invalidate(self, entity, attribute, at):
        k=(entity, attribute)
        self.invalid_after[k] = max(float(at), self.invalid_after.get(k,float('-inf')))
        self.version += 1

    def evaluate(self, entity, attribute, now, *, min_confidence=.65):
        relevant = [c for c in self.claims if c.entity == entity and c.attribute == attribute]
        valid = [c for c in relevant if c.captured_at <= now <= c.expires_at
                 and c.captured_at > self.invalid_after.get((entity,attribute),float('-inf'))
                 and c.confidence >= min_confidence]
        if not valid:
            return {'status':'stale' if relevant else 'missing', 'value':None, 'sources':[], 'evidence':[]}
        latest_per_source={}
        for c in valid:
            if c.source not in latest_per_source or c.captured_at >= latest_per_source[c.source].captured_at:
                latest_per_source[c.source]=c
        unique={str(c.value).strip().lower() for c in latest_per_source.values()}
        selected=list(latest_per_source.values())
        if len(unique) != 1:
            return {'status':'conflict', 'value':None,'sources':[c.source for c in selected],
                    'evidence':[asdict(c) for c in selected]}
        return {'status':'fresh','value':next(iter(unique)),
                'sources':[c.source for c in selected], 'evidence':[asdict(c) for c in selected]}


def fixture_ledger(case, color, *, now=10.):
    """Explicit scenario injection for controlled experimentation only.

    Does NOT pretend to model an actual second physical camera.
    """
    if case not in ('clear','conflict','stale','missing'):
        raise ValueError(case)
    ledger=EvidenceLedger()
    if case != 'missing':
        ledger.add(Claim('target','colour',color,'camera_A',1.,20.,0))
    if case == 'conflict':
        competing={'blue':'yellow','yellow':'red','red':'blue'}[color]
        ledger.add(Claim('target','colour',competing,'camera_B',2.,20.,0))
    if case == 'stale':
        ledger.invalidate('target','colour',at=5.)
    return ledger
