from roboevoswarm.evidence import EvidenceLedger, Claim, fixture_ledger
from roboevoswarm.evaluation import CASES
from benchmark_v05 import evaluate_case, run

def test_conflict():
    assert fixture_ledger('conflict','blue').evaluate('target','colour',10)['status']=='conflict'

def test_invalidation():
    e=fixture_ledger('stale','yellow')
    assert e.evaluate('target','colour',10)['status']=='stale'
    e.add(Claim('target','colour','yellow','camera_A',6,12,1))
    assert e.evaluate('target','colour',10)['status']=='fresh'

def test_missing():
    assert fixture_ledger('missing','blue').evaluate('target','colour',10)['status']=='missing'

def test_audit_deferral():
    for c in CASES:
        if c.evidence != 'clear':
            r=evaluate_case(c,'hierarchy','mock')
            assert r['committed'] is None
            assert r['correct']

def test_no_unnecessary_model_for_literal():
    case=next(c for c in CASES if c.id=='literal_blue')
    r=evaluate_case(case,'hierarchy','mock')
    assert r['correct'] and r['llm_calls']==0

def test_ambiguous_deferral():
    case=next(c for c in CASES if c.id=='multi')
    r=evaluate_case(case,'hierarchy','mock')
    assert r['committed'] is None and r['correct']

def test_batch_report(tmp_path):
    summary=run('hierarchy','mock',tmp_path)
    assert summary['n']==len(CASES)
    assert (tmp_path/'hierarchy_mock.json').is_file()
    assert summary['unsafe_commits']==0
