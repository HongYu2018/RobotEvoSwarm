from types import SimpleNamespace
from roboevoswarm.reasoning import openai_reason, OPENAI_TARGET_SCHEMA
from run_integrated import make_cases
from run_multiseed import paired_analysis, aggregate_repeats

class FakeResponses:
    def __init__(self,response):self.response=response;self.args=None
    def create(self,**kwargs): self.args=kwargs;return self.response
class FakeClient:
    def __init__(self,response):self.responses=FakeResponses(response)

def test_openai_structured_schema_and_usage():
    response=SimpleNamespace(status='completed',output_text='{"color":"yellow","confidence":0.93,"reason":"banana"}',
                             usage=SimpleNamespace(input_tokens=105,output_tokens=34))
    client=FakeClient(response)
    d=openai_reason('ripe banana block',client=client)
    assert d.color=='yellow' and d.error is None and d.input_tokens==105 and d.output_tokens==34
    assert client.responses.args['text']['format']['type']=='json_schema'
    assert client.responses.args['text']['format']['strict'] is True

def test_openai_empty_output_not_ambiguity_and_usage_retained():
    client=FakeClient(SimpleNamespace(status='completed',output_text='',usage=SimpleNamespace(input_tokens=93,output_tokens=256)))
    d=openai_reason('move blue',client=client)
    assert d.color is None and 'Empty output' in d.error and d.input_tokens==93 and d.output_tokens==256

def test_openai_incomplete_status():
    client=FakeClient(SimpleNamespace(status='incomplete',incomplete_details='max_output_tokens',output_text='',usage=SimpleNamespace(input_tokens=90,output_tokens=512)))
    d=openai_reason('move blue',client=client)
    assert d.color is None and 'incomplete' in d.error and d.output_tokens==512

def test_seed_offsets():
    a=make_cases(2,'train',seed_offset=1000)
    b=make_cases(2,'test',seed_offset=50000)
    assert {x['scene_seed'] for x in a}=={1000,1001}
    assert {x['scene_seed'] for x in b}=={50000,50001}

def test_paired_ablation():
    rows=[]
    for p,act,ok in [('fixed_hybrid',16,True),('adaptive_hybrid',10,True),('adaptive_untrained',17,False)]:
        rows.append(dict(split='test',policy=p,case_id='test_01',expected_deferral=False,
                         end_to_end_success=ok,agent_activations=act,nominal_graph_edges=act//2,correct_deferral=False))
    a=paired_analysis(rows)
    assert a['paired_differences']['trained_minus_fixed_hybrid']['delta_mean_activations']==-6
    assert a['paired_differences']['trained_minus_adaptive_untrained']['delta_success_rate']==1.0
    assert aggregate_repeats([a,a])['trained_minus_fixed_hybrid']['delta_mean_activations']['sample_sd']==0.0
