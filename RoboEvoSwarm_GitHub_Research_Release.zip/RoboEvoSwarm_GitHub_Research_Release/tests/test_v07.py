from roboevoswarm.reasoning import resolve_policy, Decision
from run_integrated import instruction_for,make_cases
from report_integrated import summarise
import xml.etree.ElementTree as ET
from pathlib import Path

def mock_local(s):return Decision('yellow','ollama',.9,'mock')
def mock_frontier(s):return Decision('blue','openai',.9,'mock')

def test_providers_always_invoked():
    d,tr=resolve_policy('Move blue', 'l2_only',local_call=mock_local)
    assert d.source=='ollama' and d.color=='yellow' and len(tr)==1
    d,tr=resolve_policy('Move yellow','l3_only',allow_openai=True,frontier_call=mock_frontier)
    assert d.source=='openai' and d.color=='blue' and len(tr)==1

def test_hierarchy_skips_simple_and_calls_indirect():
    d,tr=resolve_policy('Move the blue block','adaptive_hybrid',local_call=mock_local)
    assert d.color=='blue' and d.source=='structured'
    d,tr=resolve_policy('Move the ripe-banana-coloured block','fixed_hybrid',local_call=mock_local)
    assert d.source=='ollama'

def test_explicit_openaikey_permission():
    import pytest
    with pytest.raises(ValueError):resolve_policy('Move blue','l3_only',allow_openai=False)

def test_matched_cases_and_eval_labels():
    x=make_cases(2,'test');assert len(x)==12
    assert sum(r['expected_deferral'] for r in x)==4
    assert 'correct block' in instruction_for('blue','ambiguous')

def test_report_does_not_count_ambiguity_as_success():
    r=[{'split':'test','policy':'l1_only','expected_deferral':True,'correct_deferral':True,
        'end_to_end_success':False,'unsupported_commit':False,'infrastructure_error':False,
        'case_id':'a','error':None,'reasoning_calls':0}]
    result=summarise(r)['l1_only']
    assert result['actionable_n']==0 and result['correct_deferral_rate']==1

def test_framebuffer_supports_capture():
    root=Path(__file__).resolve().parents[1]
    tree=ET.parse(root/'assets'/'laboratory.xml')
    g=tree.find('.//visual/global')
    assert int(g.get('offwidth')) >= 800 and int(g.get('offheight')) >= 600
