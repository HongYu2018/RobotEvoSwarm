"""Offline regression tests for the final research design (no fabricated outcomes)."""
import pytest
from roboevoswarm.adaptation import ContextualSelector, Experience
from roboevoswarm.scenarios import scene_spec
from run_final_study import (training_cases,testing_cases as make_test_scenarios,classify,score,paired_comparisons,
                            statistics_for,aggregate_repeats)
from run_integrated import case_id

def test_recovery_rule_vs_initial():
    c=ContextualSelector('rule_fixed')
    assert c.select('sense','initial',0)['action']=='lean'
    assert c.select('recover','primary_depth_missing',0)['action']=='redundant'
    assert 'second_rgbd_camera' in c.trace[1]['agents']
    assert c.select('execute','manipulation',0)['action']=='lean'

def test_rule_never_learns():
    e=Experience(); c=ContextualSelector('rule_fixed',e)
    c.select('recover','primary_depth_missing',0);c.learn(False)
    assert e.records=={}

def test_random_replicable_and_can_change_by_seed():
    a=ContextualSelector('random_fixed',random_seed=23)
    b=ContextualSelector('random_fixed',random_seed=23)
    assert [a.select('sense','initial',i)['action'] for i in range(16)]==[b.select('sense','initial',i)['action'] for i in range(16)]
    assert len({a['action'] for a in ContextualSelector('random_fixed',random_seed=23).trace})==0

def test_family_shift_and_seed_disjoint():
    a=scene_spec(23,'test','depth_dropout','blue','standard')
    b=scene_spec(23,'test','depth_dropout','blue','shifted')
    assert a['initial_pose']!=b['initial_pose'] and a['family']=='standard' and b['family']=='shifted'
    assert scene_spec(23,'test','dual_depth_dropout','blue','shifted')['disturbance']=='dual_depth_dropout'
    with pytest.raises(ValueError):scene_spec(23,'test','depth_dropout','blue','arbitrary')

def test_unseen_disturbance_not_in_training():
    train=list(training_cases(3,0));test=list(make_test_scenarios(2,50000))
    assert {c['disturbance'] for c in train}=={'relocation','depth_dropout'}
    assert {'relocation','depth_dropout','dual_depth_dropout'}=={c['disturbance'] for c in test}
    assert len(test)==2*2*3*3
    assert not set(c['scene_seed'] for c in train)&set(c['scene_seed'] for c in test)
    assert len({case_id(c) for c in test})==len(test)

def row(policy,case,success=False,deferred=False,activations=10):
    return dict(policy=policy,case_id=case_id(case),split='test',scene_family=case['scene_family'],
         disturbance=case['disturbance'],expected_deferral=case['expected_deferral'],
         end_to_end_success=success,correct_deferral=deferred,unsupported_commit=False,
         grasped=False,environment_outcome='safe_deferral' if deferred else 'failure',
         infrastructure_error=False,agent_activations=activations,nominal_graph_edges=3,
         llm_input_tokens=0,llm_output_tokens=0,reasoning_calls=0)

def test_safe_deferral_is_not_recovery_success():
    c=next(c for c in make_test_scenarios(1,50000) if c['disturbance']=='depth_dropout' and c['template']=='literal')
    r=row('rule_hybrid',c,deferred=True)
    assert classify(r)=='actionable' and not score(r)

def test_unrecoverable_safe_abstention():
    c=next(c for c in make_test_scenarios(1,50000) if c['disturbance']=='dual_depth_dropout' and c['template']=='literal')
    assert classify(row('rule_hybrid',c,deferred=True))=='unrecoverable'
    assert score(row('rule_hybrid',c,deferred=True))
    assert not score(row('rule_hybrid',c,success=True))

def test_ambiguity_requires_explicit_deferral():
    c=next(c for c in make_test_scenarios(1,50000) if c['template']=='ambiguous')
    assert score(row('fixed_hybrid',c,deferred=True))
    assert not score(row('fixed_hybrid',c,deferred=False))

def test_pairing_and_category_denominators():
    cases=list(make_test_scenarios(1,50000));rows=[]
    for case in cases:
        t='adaptive_hybrid';r='rule_hybrid'
        ok=case['disturbance']!='dual_depth_dropout' and not case['expected_deferral']
        defer=not ok
        rows.append(row(t,case,success=ok,deferred=defer,activations=8))
        rows.append(row(r,case,success=ok,deferred=defer,activations=10))
    summary=statistics_for(rows)
    assert summary['adaptive_hybrid']['actionable']=={'n':8,'correct':8,'rate':1.0}
    assert summary['adaptive_hybrid']['unrecoverable']['n']==4
    assert summary['adaptive_hybrid']['ambiguous']['n']==6
    paired=paired_comparisons(rows)
    assert paired['adaptive_hybrid_minus_rule_hybrid']['delta_actionable_success']==0
    assert paired['adaptive_hybrid_minus_rule_hybrid']['delta_mean_activations']==-2
    across=aggregate_repeats([{'paired':paired},{'paired':paired}])
    assert across['adaptive_hybrid_minus_rule_hybrid']['delta_mean_activations']['sd']==0

def test_incomplete_match_rejected():
    c=list(make_test_scenarios(1,50000))[0]
    c2=list(make_test_scenarios(1,50000))[1]
    with pytest.raises(ValueError):paired_comparisons([row('adaptive_hybrid',c),row('adaptive_hybrid',c2),row('rule_hybrid',c)])

def test_final_runner_writes_complete_report_with_mocked_physics(tmp_path, monkeypatch):
    """Checks file/report plumbing only; all outcomes are TEST FIXTURES, not simulation data."""
    from types import SimpleNamespace
    import json
    import run_final_study as f
    def fake_run(project,rep_dir,case,policy,**kwargs):
        is_amb=case['expected_deferral']
        unrecoverable=case['disturbance']=='dual_depth_dropout'
        deferred=is_amb or unrecoverable
        data=row(policy,case,success=not deferred,deferred=deferred)
        data.update(case)
        data['policy']=policy
        data['case_id']=case_id(case)
        data['infrastructure_error']=False
        data['semantic_decision']={'source':'structured','color':case['color'],'error':None}
        return data
    monkeypatch.setattr(f,'run_one',fake_run)
    out=tmp_path/'study'
    f.run(SimpleNamespace(output=str(out),repeats=2,train=2,test=1,
                          include_reasoners=False,allow_openai=False))
    assert (out/'FINAL_REPORT.md').exists()
    obj=json.loads((out/'FINAL_RESULTS.json').read_text())
    assert len(obj['replicates'])==2
    assert obj['replicates'][0]['test_episodes']==90
    assert obj['replicates'][0]['stats']['rule_hybrid']['unrecoverable']['n']==4
    assert 'adaptive_hybrid_minus_rule_hybrid' in obj['paired_across_repeats']
