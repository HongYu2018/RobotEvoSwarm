import ast
from pathlib import Path


def test_headless_mujoco_scope():
    source = Path(__file__).resolve().parents[1] / "main.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    run = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "run_episode")
    assert not any(isinstance(n, ast.Import) and any(a.name == "mujoco.viewer" for a in n.names) for n in ast.walk(run))
    assert any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "mj_step" for n in ast.walk(run))
