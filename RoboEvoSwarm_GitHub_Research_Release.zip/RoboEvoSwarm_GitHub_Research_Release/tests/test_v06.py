from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from roboevoswarm.scenarios import scene_spec
from diagnose_openai import analyse
from run_study import summarise


def test_scenes_repeatable_and_split():
    a=scene_spec(11,'train','relocation','blue')
    b=scene_spec(11,'test','relocation','blue')
    assert a == scene_spec(11,'train','relocation','blue')
    assert a['initial_pose'] != b['initial_pose']
    assert a['initial_pose'] != a['moved_pose']


def test_scene_colors():
    for c in ('red','blue','yellow'):
        s=scene_spec(4,'test','relocation',c)
        assert s['initial_pose'][2] == .058
        assert .30 < s['moved_pose'][0] < .4


def test_openai_diagnostics():
    data={'summary':{'correct':1,'n':3}, 'rows':[
      {'id':'a','family':'x','correct':False,'expected':'blue','proposed':None,'committed':None,'evidence_status':'fresh','trace':[{'error':'ValueError: invalid JSON'}]},
      {'id':'b','family':'y','correct':False,'expected':'red','proposed':'yellow','committed':'yellow','evidence_status':'fresh','trace':[{}]},
      {'id':'c','family':'z','correct':True}]}
    out=analyse(data)
    assert out['failure_categories']['provider_or_parse_error']==1
    assert out['failure_categories']['wrong_colour']==1


def test_aggregates():
    rows=[{'split':'test','mode':'learned','success':True,'agent_activations':10,'wall_seconds':1.,'placement_error_m':.01},
          {'split':'test','mode':'learned','success':False,'agent_activations':12,'wall_seconds':2.,'placement_error_m':.2}]
    s=summarise(rows)['test/learned']
    assert s['success_rate']==.5 and s['mean_activations']==11


def test_report_figures_requires_data(tmp_path):
    from make_paper_figures import make_figures
    import pytest
    with pytest.raises(FileNotFoundError):
        make_figures(tmp_path/'missing',tmp_path/'out')


def test_depth_outage_source_inspection():
    source=(Path(__file__).resolve().parents[1]/'roboevoswarm'/'vision.py').read_text()
    assert 'depth_dropout' in source and 'np.zeros_like(depth)' in source


def test_recovery_policy_learns_value_of_secondary_camera():
    from roboevoswarm.adaptation import ContextualSelector, Experience
    memory=Experience()
    first=ContextualSelector('learned',memory)
    assert first.select('recover','primary_depth_missing',0)['action']=='lean'
    first.learn(False)
    second=ContextualSelector('learned',memory)
    assert second.select('recover','primary_depth_missing',0)['action']=='redundant'
    assert 'second_rgbd_camera' in second.trace[0]['agents']
    second.learn(True)
    third=ContextualSelector('learned',memory)
    assert third.select('recover','primary_depth_missing',0)['action']=='redundant'


def test_two_camera_model_is_declared():
    import xml.etree.ElementTree as ET
    root=ET.parse(Path(__file__).resolve().parents[1]/'assets'/'laboratory.xml').getroot()
    names=[x.attrib.get('name') for x in root.iter('camera')]
    assert 'lab_camera' in names and 'lab_camera_b' in names
