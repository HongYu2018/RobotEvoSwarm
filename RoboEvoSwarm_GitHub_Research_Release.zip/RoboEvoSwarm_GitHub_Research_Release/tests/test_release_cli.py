import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_unified_help():
    result=subprocess.run([sys.executable,str(ROOT/'robo_demo.py'),'--help'],capture_output=True,text=True)
    assert result.returncode==0 and 'study' in result.stdout and 'demo' in result.stdout

def test_example_result_schema():
    p=ROOT/'examples/reported_results/FINAL_CONFIRMATORY_RETRY_excerpt.json'
    d=json.loads(p.read_text(encoding='utf8'))
    assert d['policies']['adaptive_hybrid']['recoverable_success_per_repeat']==[64]*5
    assert d['policies']['rule_hybrid']['recoverable_success_per_repeat']==[64]*5

def test_private_env_not_included():
    assert not (ROOT/'.env').exists()
    assert (ROOT/'.env.example').is_file()
