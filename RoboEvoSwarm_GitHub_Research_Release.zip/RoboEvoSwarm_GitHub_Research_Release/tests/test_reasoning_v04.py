import json
from types import SimpleNamespace
from roboevoswarm.reasoning import (Decision, load_env, ollama_chat, openai_reason,
                                     parse_proposal, resolve_task, structured_colour)


def test_literal_no_llm_call():
    def fail(_): raise AssertionError('LLM should not be called')
    d, trace = resolve_task('Place the blue block in the green target',local_call=fail)
    assert d.color == 'blue' and trace[0]['source'] == 'structured'


def test_local_transport_contract():
    def fake(request,timeout):
        assert request.full_url.endswith('/api/chat')
        payload=json.loads(request.data)
        assert payload['stream'] is False and payload['model']=='test:small'
        return {'message':{'content':'{"color":"blue","confidence":0.94,"reason":"sky"}'},
                'prompt_eval_count':35,'eval_count':14}
    d=ollama_chat('Move the block the colour of the sky',model='test:small',transport=fake)
    assert d.color=='blue' and d.input_tokens==35 and d.output_tokens==14


def test_no_auto_frontier_without_explicit_permission():
    local=lambda _: Decision(None,'ollama',0,'failed',error='offline')
    def fail(_): raise AssertionError('frontier invoked without permission')
    d,trace=resolve_task('Move the sky-coloured object', mode='auto',allow_openai=False,
                         local_call=local,frontier_call=fail)
    assert d.color is None and len(trace)==1


def test_frontier_mock_only_when_enabled():
    local=lambda _: Decision(None,'ollama',0,'failed')
    frontier=lambda _: Decision('yellow','openai',.9,'ripe banana')
    d,trace=resolve_task('Move the object with the colour of a ripe banana',mode='auto',
                         allow_openai=True,local_call=local,frontier_call=frontier)
    assert d.color=='yellow' and len(trace)==2


def test_openai_response_adapter_mock():
    class Fake:
        responses=SimpleNamespace(create=lambda **kwargs: SimpleNamespace(
            output_text='{"color":"yellow","confidence":0.85,"reason":"banana"}',
            usage=SimpleNamespace(input_tokens=58,output_tokens=18)))
    d=openai_reason('Move the ripe-banana-coloured object',model='test-frontier',client=Fake())
    assert d.color=='yellow' and d.input_tokens==58


def test_bad_or_unsafe_proposals_are_rejected():
    for payload in ['{"color":"green","confidence":1}',
                    'First move joint 2. {"color":"blue","confidence":1}',
                    '{"color":"blue","confidence":4}']:
        try: parse_proposal(payload)
        except (ValueError, json.JSONDecodeError): pass
        else: raise AssertionError(payload)
    assert parse_proposal('{"color":"red","confidence":0.4}')[0] is None


def test_multiple_explicit_colours_never_guess():
    d=structured_colour('Choose either the red block or blue block')
    assert d.color is None


def test_env_does_not_override_existing(monkeypatch,tmp_path):
    f=tmp_path/'.env'; f.write_text('OPENAI_API_KEY=do-not-use-this\nOLLAMA_MODEL=test:1\n')
    monkeypatch.setenv('OPENAI_API_KEY','already-set')
    monkeypatch.delenv('OLLAMA_MODEL',raising=False)
    load_env(f)
    import os
    assert os.environ['OPENAI_API_KEY']=='already-set'
    assert os.environ['OLLAMA_MODEL']=='test:1'
