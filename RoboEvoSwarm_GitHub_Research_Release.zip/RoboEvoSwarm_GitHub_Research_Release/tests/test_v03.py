import numpy as np
from roboevoswarm.vision import color_mask, identify, backproject_pixels
from roboevoswarm.adaptation import Experience, ContextualSelector

def test_colours():
    im=np.array([[[240,45,35],[36,77,235],[235,195,20],[128,128,128]]],dtype=np.uint8)
    for c,i in [('red',0),('blue',1),('yellow',2)]:
        mask=color_mask(im,c)
        assert mask[0,i] and int(mask.sum()) == 1

def test_no_detection_is_safe():
    im=np.zeros((40,40,3),dtype=np.uint8)
    result=identify(im,np.ones((40,40)), 'blue',np.zeros(3), np.eye(3), 50)
    assert result.status=='missing' and result.xyz is None

def test_backprojection_center():
    p=backproject_pixels(np.array([[49.5,49.5]]), np.array([1.]),np.zeros(3),np.eye(3), 60,100,100)
    assert np.allclose(p,[0,0,-1])

def test_experience_roundtrip(tmp_path):
    e=Experience()
    e.update('sense:stale','redundant',.9)
    e.update('sense:stale','lean',-.3)
    assert e.choose('sense:stale')=='redundant'
    path=tmp_path/'experience.json'
    e.save(path)
    assert Experience.load(path).records==e.records

def test_safety_covered():
    for mode in ('learned','lean_fixed','reactive_fixed'):
        s=ContextualSelector(mode)
        agents=s.select('execute','normal',0)['agents']
        assert 'safety' in agents and 'manipulation' in agents

def test_explores_alternatives():
    e=Experience()
    assert e.choose('plan:fresh') == 'lean'
    e.update('plan:fresh','lean',1.)
    assert e.choose('plan:fresh') == 'redundant'
    e.update('plan:fresh','redundant',.88)
    assert e.choose('plan:fresh') == 'lean'
