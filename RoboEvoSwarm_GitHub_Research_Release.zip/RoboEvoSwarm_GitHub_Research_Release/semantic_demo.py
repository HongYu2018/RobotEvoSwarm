"""Standalone L1/L2/L3 decision test; no MuJoCo required."""
import argparse, json
from roboevoswarm.reasoning import load_env, resolve_task

p=argparse.ArgumentParser()
p.add_argument('--instruction',default='Move the object with the colour of a clear daytime sky to the green target.')
p.add_argument('--llm-mode',choices=['none','local','auto','frontier'],default='auto')
p.add_argument('--allow-openai',action='store_true')
p.add_argument('--env-file',default='.env')
a=p.parse_args()
load_env(a.env_file)
decision,trace=resolve_task(a.instruction,mode=a.llm_mode,allow_openai=a.allow_openai)
print(json.dumps({'decision':decision.public_dict(),'llm_trace':trace},indent=2))
if decision.color is None: raise SystemExit(2)
