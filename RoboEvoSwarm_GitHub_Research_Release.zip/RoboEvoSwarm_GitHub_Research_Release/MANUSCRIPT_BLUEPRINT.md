# Manuscript development blueprint — RoboEvoSwarm

## Proposed title

**RoboEvoSwarm: Selective Heterogeneous Intelligence and Experience-Guided Coordination for Robust Robotic Manipulation**

Alternative emphasising mechanism rather than a stronger unproven self-evolution claim:

**Evidence-Gated Coordination of Heterogeneous Agents for Instruction-Guided Robotic Manipulation under Sensor Failures**

## Paper's central question

When does selective orchestration of conventional robotics specialists, compact language-model reasoning and a shared evidence-aware World Model improve task reliability and coordination efficiency over fixed redundancy and a well-engineered event-triggered rule?

## Suggested contributions to substantiate

1. **An embodied hierarchical agent architecture**, combining bounded L1 robotics specialists, L2 local linguistic reasoning, optional L3 frontier critique, and an evidence-gated World Model. Distinguish engineering integration from an inherently novel mechanism.
2. **Experience-guided capability composition**, with a transparent contextual learner selecting from predefined safe graph motifs (lean and redundant). Explicitly avoid claiming unconstrained evolution or novel-agent invention.
3. **A controlled evidence and fault benchmark**, containing relocated targets, single/dual depth outages, ambiguous instructions and held-out position shifts, with principled scoring of action vs safe abstention.
4. **A reproducible matched evaluation and mechanism ablation** against always-redundant, event-triggered rule, random, and untrained selectors. Be prepared to discuss null superiority against the strong rule.

## Proposed outline

1. Introduction: limits of uniformly expensive general reasoning; need for safe, contextual embodied capability orchestration.
2. Related work: multi-agent robotics, hierarchical systems, model-based belief updating, language-guided manipulation, selective sensing, contextual bandits, evidence provenance and deferral.
3. Problem definition: agents, capability interfaces, the shared World Model, graph choice, safety invariants, and selective escalation; formalise objective subject to completion and safety constraints.
4. RoboEvoSwarm: specialist capabilities, semantic routing, perception and evidence gate, contextual learning, graph trace, decision and manipulation pipeline.
5. Experimental methods: simulated arm, scripted disturbances, scene split, all baselines and evaluation definitions; full protocol in `PAPER_EVALUATION_PROTOCOL.md`.
6. Results: (a) L1/L2/L3 interpretation, (b) semantic-to-robot integration, (c) trained/untrained vs fixed and strong rule, (d) shift and dual-fault safety, (e) costs and ablations.
7. Discussion: interpretation under strong rule, why self-evolution is bounded, external validity of MuJoCo and simplified grasp, what is known and unknown about energy and reliability.
8. Conclusion: defensible contribution based on observed effects, without extrapolating to general-purpose embodied intelligence.

## Writing plan

- Reuse the existing measured v0.7.1 results as a *preliminary study*, with exact experimental labels and limits.
- Treat v0.8 as the *confirmatory study*. Insert its final results only after running the real experiment.
- Perform paired analysis and show failure cases instead of suppressing them.
- Figure architecture must visually distinguish L1 conventional tools, L2 Ollama, L3 OpenAI, the World Model, the evidence gate, and contextual choice among predefined graphs.
- Figures using MuJoCo should be actual simulator screenshots (manual is fine); diagrammatic conceptual figures should be clearly labelled as schematics.
- Validate references and select a journal only after the contribution is finalised, avoiding overlap with the EvoSwarm and BioEvoSwarm submissions.

## Interpretation decisions fixed in advance

| Confirmatory finding | Acceptable manuscript interpretation |
|---|---|
| Trained > untrained; trained = rule | Experience learns a useful predefined trigger but does not outperform simple engineering; position learning as one implementation, not central novelty |
| Trained = rule; learned has lower activations | Claim cost-performance tradeoff only if both success and safety match on paired held-out cases |
| Trained > rule on shifted conditions | Conditional evidence for superior generalisation; quantify uncertainty and explain scenario structure |
| Rule > trained | Report rule's superiority; centre paper on bounded hybrid intelligence and evidence-aware safe control |
| Dual outage leads to safe deferral | Shows risk-controlled stopping in a scripted unrecoverable condition, not autonomous fault repair |
| OpenAI provider errors | Count as interface failures and separate from semantic misinterpretation |

**Key standard:** scientific novelty and publishability depend on the resulting causal and comparative evidence, not solely the amount of code or how many experiments are run.
