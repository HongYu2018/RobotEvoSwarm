"""Build manuscript-ready figures from REAL experimental result files.

No synthetic MuJoCo screenshots are created. Frame montages only use image files
saved by MuJoCo Renderer during a real run. Missing data is reported, never filled.
"""
from pathlib import Path
import argparse,csv,json
from collections import defaultdict


def make_figures(study, output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from PIL import Image, ImageOps, ImageDraw
    study=Path(study); output=Path(output);output.mkdir(parents=True,exist_ok=True)
    f=study/'all_runs.csv'
    if not f.exists():raise FileNotFoundError(f'Run run_study.py first; missing {f}')
    with f.open(encoding='utf-8',newline='') as handle: rows=list(csv.DictReader(handle))
    tests=[x for x in rows if x['split']=='test']
    groups=defaultdict(list)
    for x in tests: groups[x['mode']].append(x)
    modes=['lean_fixed','reactive_fixed','learned']
    if not any(groups.values()):raise ValueError('No test results; complete test split first')
    # Success is meaningful only on task-feasible relocation trials. Sensor
    # outages should be evaluated by correct safe deferral, not miscounted as
    # physical failures of an eligible task.
    eligible={m:[x for x in groups[m] if x['disturbance']=='relocation'] for m in modes}
    success=[sum(x['success']=='True' for x in eligible[m])/len(eligible[m]) if eligible[m] else float('nan') for m in modes]
    policy=[sum(x.get('policy_correct')=='True' for x in groups[m])/len(groups[m]) if groups[m] else float('nan') for m in modes]
    faults={m:[x for x in groups[m] if x['disturbance']=='depth_dropout'] for m in modes}
    recovery=[sum(x['success']=='True' for x in faults[m])/len(faults[m]) if faults[m] else float('nan') for m in modes]
    activations=[sum(float(x['agent_activations']) for x in groups[m])/len(groups[m]) if groups[m] else float('nan') for m in modes]
    fig,ax=plt.subplots(figsize=(7,4))
    ax.bar(modes,success);ax.set_ylim(0,1.04);ax.set_ylabel('Held-out success rate');ax.set_title('Robotic task completion by coordination policy');fig.tight_layout()
    fig.savefig(output/'fig_success_rate.png',dpi=250);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    ax.bar(modes,policy);ax.set_ylim(0,1.04);ax.set_ylabel('Correct action or safe deferral rate')
    ax.set_title('Overall policy correctness, including sensor outages');fig.tight_layout()
    fig.savefig(output/'fig_policy_correctness.png',dpi=250);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    ax.bar(modes,recovery);ax.set_ylim(0,1.04);ax.set_ylabel('Physical completion rate after primary depth outage')
    ax.set_title('Recovery through alternative perception specialists');fig.tight_layout()
    fig.savefig(output/'fig_fault_recovery.png',dpi=250);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    ax.bar(modes,activations);ax.set_ylabel('Mean nominal agent activations');ax.set_title('Specialist activation in held-out robot tasks');fig.tight_layout()
    fig.savefig(output/'fig_agent_activations.png',dpi=250);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    for mode in modes:
        seq=sorted(eligible[mode],key=lambda z:int(z['scene_seed']))
        seq=[x for x in seq if x['placement_error_m'] not in ('','None',None)]
        if seq:ax.plot([int(x['scene_seed']) for x in seq],[float(x['placement_error_m'])*1000 for x in seq],'-o',label=mode)
    ax.set_xlabel('Held-out scene seed');ax.set_ylabel('Final horizontal error (mm)');ax.set_title('Placement outcome on relocation trials (failures retained)');ax.legend();fig.tight_layout()
    fig.savefig(output/'fig_per_scene_error.png',dpi=250);plt.close(fig)
    # Plot the observed active-capability trace from an actual held-out episode.
    for summary in sorted(study.glob('runs/**/summary.json')):
        row=json.loads(summary.read_text(encoding='utf-8'))
        trace=row.get('graph_history',[])
        if row.get('split')!='test' or not trace: continue
        fig,ax=plt.subplots(figsize=(9,4))
        ax.plot(range(len(trace)),[len(z['agents']) for z in trace],'-o')
        ax.set_xticks(range(len(trace)),[z['stage'] for z in trace],rotation=50,ha='right')
        ax.set_ylabel('Active specialists per selection')
        ax.set_xlabel('Coordination stage')
        ax.set_title('Observed active capability graph size (one held-out episode)')
        fig.tight_layout();fig.savefig(output/'fig_agent_topology_trace.png',dpi=250);plt.close(fig)
        break
    # First image-complete test run is selected automatically; never draw fake frames.
    for summary in sorted(study.glob('runs/**/summary.json')):
        x=json.loads(summary.read_text(encoding='utf-8'))
        photos=x.get('paper_images') or []
        if x.get('split')!='test' or not x.get('success') or len(photos)<6:continue
        images=[]
        for photo in photos:
            fp=summary.parent/photo['file']
            if fp.exists():
                pic=Image.open(fp).convert('RGB').resize((560,420))
                label=f"{photo['label']}  (t={photo['sim_time']} s)"
                images.append((label,pic))
        if not images:continue
        cols=2; rows_n=(len(images)+cols-1)//cols
        canvas=Image.new('RGB',(cols*580,rows_n*464),'white')
        d=ImageDraw.Draw(canvas)
        for i,(label,img) in enumerate(images):
            x0=(i%cols)*580+10;y0=(i//cols)*464+32
            canvas.paste(img,(x0,y0));d.text((x0,y0-23),label,fill='black')
        canvas.save(output/'fig_mujoco_execution_sequence.png')
        (output/'fig_mujoco_provenance.json').write_text(json.dumps({'source_summary':str(summary),'frames':photos},indent=2),encoding='utf-8')
        break
    (output/'figure_manifest.json').write_text(json.dumps({'source':str(f),'test_runs':len(tests),
      'figures':sorted(p.name for p in output.glob('fig_*.png')),'caveat':'Images are actual MuJoCo render outputs and plots use test CSV; zero test runs are not permitted.'},indent=2),encoding='utf-8')
    print('Figures:',*[str(p) for p in sorted(output.glob('fig_*.png'))],sep='\n - ')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--study',default='results/study_v06')
    p.add_argument('--output',default='results/paper_figures')
    a=p.parse_args();make_figures(a.study,a.output)
