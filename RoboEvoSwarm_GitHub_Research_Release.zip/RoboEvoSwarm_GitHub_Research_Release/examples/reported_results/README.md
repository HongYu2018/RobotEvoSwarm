# Previously reported confirmatory example

`FINAL_CONFIRMATORY_RETRY_excerpt.json` transcribes the final successful results supplied by the research team. It is **not** output from running this GitHub package in its build environment. Raw episode logs for that successful retry were not present in the material available for packaging, so no episode-level samples or model traces have been invented.

Do not confuse with the earlier `FINAL_CONFIRMATORY_01.zip` attempt, in which Windows application control blocked MuJoCo imports and no physics episodes executed.
