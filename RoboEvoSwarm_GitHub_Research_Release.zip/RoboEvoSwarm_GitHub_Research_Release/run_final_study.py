"""Final confirmatory RoboEvoSwarm study: preregisterable held-out environment families.

Training is *only* on standard scenes with relocation / single-camera outage.
Testing is on independent standard+shifted scenes and includes a novel
unrecoverable two-camera depth outage. All policies receive matched cases.
Never uses evaluator ground truth as a perceptual substitute.
"""
from __future__ import annotations
import argparse, csv, json, math, statistics, sys
from collections import defaultdict
from pathlib import Path
from run_integrated import run_one, instruction_for, case_id

DEFAULT_POLICIES=('fixed_hybrid','rule_hybrid','random_hybrid','adaptive_hybrid','adaptive_untrained')
DISTURBANCES=('relocation','depth_dropout','dual_depth_dropout')
TEMPLATES=('literal','metaphor','ambiguous')
FAMILIES=('standard','shifted')

def training_cases(n,offset):
    for seed in range(offset,offset+n):
        for disturbance in ('relocation','depth_dropout'):
            color=('blue','red','yellow')[seed%3]
            yield dict(scene_seed=seed,split='train',color=color,disturbance=disturbance,
                       template='literal',instruction=instruction_for(color,'literal'),
                       scene_family='standard',expected_deferral=False)

def testing_cases(n,offset,families=FAMILIES):
    for seed in range(offset,offset+n):
        color=('blue','red','yellow')[seed%3]
        for family in families:
            for disturbance in DISTURBANCES:
                for template in TEMPLATES:
                    yield dict(scene_seed=seed,split='test',color=color,disturbance=disturbance,
                               template=template,instruction=instruction_for(color,template),
                               scene_family=family,expected_deferral=template=='ambiguous')

def classify(row):
    if row['expected_deferral']:return 'ambiguous'
    if row['disturbance']=='dual_depth_dropout':return 'unrecoverable'
    return 'actionable'

def score(row):
    typ=classify(row)
    if typ=='ambiguous':return bool(row.get('correct_deferral')) and not row.get('unsupported_commit')
    if typ=='unrecoverable':return (row.get('environment_outcome')=='safe_deferral' and
                                    not row.get('grasped') and not row.get('unsupported_commit') and
                                    not row.get('infrastructure_error'))
    return bool(row.get('end_to_end_success')) and not row.get('infrastructure_error')

def statistics_for(rows):
    result={}
    for policy in sorted({r['policy'] for r in rows}):
        pr=[r for r in rows if r['policy']==policy]
        classes={name:[r for r in pr if classify(r)==name] for name in ('actionable','ambiguous','unrecoverable')}
        result[policy]={'n':len(pr),'correct_overall':sum(score(r) for r in pr),
          'overall_rate':sum(score(r) for r in pr)/len(pr),
          'unsafe_commits':sum(bool(r.get('unsupported_commit')) for r in pr),
          'infrastructure_errors':sum(bool(r.get('infrastructure_error')) for r in pr),
          'llm_calls':sum(int(r.get('reasoning_calls') or 0) for r in pr),
          'llm_tokens':sum(int(r.get('llm_input_tokens') or 0)+int(r.get('llm_output_tokens') or 0) for r in pr),
          'mean_agent_activations':statistics.mean(float(r.get('agent_activations') or 0) for r in pr),
          'mean_edge_events':statistics.mean(float(r.get('nominal_graph_edges') or 0) for r in pr),
          'secondary_camera_attempts':sum(int(r.get('secondary_camera_uses') or 0) for r in pr)}
        for name,items in classes.items():
            result[policy][name]={'n':len(items),'correct':sum(score(r) for r in items),
                                   'rate':sum(score(r) for r in items)/len(items) if items else None}
        result[policy]['by_family']={family:{'n':len(items),'rate':sum(score(r) for r in items)/len(items)}
                                       for family in FAMILIES if (items:=[r for r in pr if r.get('scene_family')==family])}
        result[policy]['by_disturbance']={d:{'n':len(items),'rate':sum(score(r) for r in items)/len(items)}
                                         for d in DISTURBANCES if (items:=[r for r in pr if r['disturbance']==d])}
    return result

def paired_comparisons(rows,baseline='adaptive_hybrid'):
    mapping={(r['policy'],r['case_id']):r for r in rows}
    ids=sorted({r['case_id'] for r in rows if r['policy']==baseline})
    results={}
    for competitor in sorted({r['policy'] for r in rows}-{baseline}):
        comparable=[(mapping[(baseline,i)],mapping[(competitor,i)]) for i in ids
                    if (baseline,i) in mapping and (competitor,i) in mapping]
        if len(comparable)!=len(ids):
            raise ValueError(f'Unmatched evaluation: {competitor} {len(comparable)}/{len(ids)}')
        relevant=[(a,b) for a,b in comparable if classify(a)=='actionable']
        results[f'{baseline}_minus_{competitor}']={
            'matched_cases':len(comparable),'matched_actionable':len(relevant),
            'delta_actionable_success':statistics.mean(int(score(a))-int(score(b)) for a,b in relevant) if relevant else None,
            'delta_overall_correctness':statistics.mean(int(score(a))-int(score(b)) for a,b in comparable),
            'delta_mean_activations':statistics.mean(float(a.get('agent_activations') or 0)-float(b.get('agent_activations') or 0) for a,b in comparable),
            'delta_mean_edges':statistics.mean(float(a.get('nominal_graph_edges') or 0)-float(b.get('nominal_graph_edges') or 0) for a,b in comparable),
            'paired_discordant_actionable':{'adaptive_only':sum(score(a) and not score(b) for a,b in relevant),
                                            'competitor_only':sum(score(b) and not score(a) for a,b in relevant)}
        }
    return results

def write_rows(path,rows):
    path.mkdir(parents=True,exist_ok=True)
    (path/'all_runs.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    data=[{k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in rows]
    with (path/'all_runs.csv').open('w',newline='',encoding='utf-8') as f:
        cols=sorted(set().union(*(r.keys() for r in data)))
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(data)

def aggregate_repeats(summaries):
    result={}
    comparisons=sorted(set().union(*(s['paired'].keys() for s in summaries)))
    for c in comparisons:
        result[c]={}
        for k in ('delta_actionable_success','delta_overall_correctness','delta_mean_activations','delta_mean_edges'):
            values=[s['paired'][c][k] for s in summaries if c in s['paired'] and s['paired'][c][k] is not None]
            result[c][k]={'mean':statistics.mean(values),'sd':statistics.stdev(values) if len(values)>1 else None,'values':values}
    return result

def render_report(root,summaries,aggregate,policies,opts):
    lines=['# RoboEvoSwarm v0.8 — Final confirmatory evaluation','',
         f'Independent training repetitions: **{opts.repeats}**; train seeds per repetition: **{opts.train}**; held-out seeds per repetition: **{opts.test}**, separately generated.','',
         f'Policies: {", ".join(policies)}.','',
         'Training includes standard relocation and primary-depth outage. Evaluation includes both standard and shifted scenes and an **unseen dual-depth-outage** condition.','',
         '## Per-repetition results','',
         '| Replicate | Policy | Recoverable actionable | Ambiguous deferral | Unrecoverable safe deferral | Nominal activations | Nominal edge events | LLM calls |',
         '|---|---|---:|---:|---:|---:|---:|---:|']
    for rep,s in enumerate(summaries,1):
        for p in policies:
            r=s['stats'][p]
            def cell(k):
                x=r[k];return f"{x['correct']}/{x['n']}" if x['n'] else 'N/A'
            lines.append(f"| {rep} | {p} | {cell('actionable')} | {cell('ambiguous')} | {cell('unrecoverable')} | {r['mean_agent_activations']:.2f} | {r['mean_edge_events']:.2f} | {r['llm_calls']} |")
    lines+=['','## Paired effects across independent training repetitions','',
             '| Adaptive minus comparator | Δ actionable success (mean ± SD) | Δ activations (mean ± SD) | Δ edge events (mean ± SD) |',
             '|---|---:|---:|---:|']
    for k,v in aggregate.items():
        def fmt(f):
            a=v[f];return f"{a['mean']:+.4f} ± {a['sd']:.4f}" if a['sd'] is not None else f"{a['mean']:+.4f}"
        lines.append(f"| {k} | {fmt('delta_actionable_success')} | {fmt('delta_mean_activations')} | {fmt('delta_mean_edges')} |")
    lines+=['','## Interpretation and publication guardrails','',
             '- **Do not pool repeated scene evaluations as independent random samples.** Training repeats and scene families must be distinguished.','- The strongest comparator is the simple event-triggered `rule_hybrid`. If it matches or beats learned routing, acknowledge this directly.',
             '- Dual-camera depth failure is **unrecoverable** in this simplified environment: correct behaviour is safe deferral, not physical completion.',
             '- Shifted scene layouts lie within a nearby but distinct position distribution. This does not establish open-world generalisation.',
             '- The model learns a bounded contextual preference among predefined lean/redundant compositions. It does **not** invent agent skills, communication protocols or graph topology.',
             '- RGB-D is classical segmentation with a simulated weld grasp. Sensor faults and relocation are scripted and visible as designated events.',
             '- LLM model calls/token totals are recorded, but this script does not claim energy or pricing savings.',
             '- Figures should be generated from actual run data; MuJoCo captures can be collected manually.',
             '- This experiment alone is not evidence of L3 superiority: use the separately controlled frontier-enabled sub-study if needed.',
             '']
    (root/'FINAL_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    return '\n'.join(lines)

def plot_results(root,summaries,policies):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        x=list(range(len(policies)));fig,ax=plt.subplots(figsize=(10,5))
        values=[statistics.mean(s['stats'][p]['actionable']['rate'] for s in summaries) for p in policies]
        ax.bar(x,values);ax.set_xticks(x,policies,rotation=25,ha='right');ax.set_ylabel('Recoverable actionable task success');ax.set_ylim(0,1.05)
        fig.tight_layout();fig.savefig(root/'fig_actionable_success.png',dpi=180);plt.close(fig)
        fig,ax=plt.subplots(figsize=(10,5))
        values=[statistics.mean(s['stats'][p]['mean_agent_activations'] for s in summaries) for p in policies]
        ax.bar(x,values);ax.set_xticks(x,policies,rotation=25,ha='right');ax.set_ylabel('Nominal specialist activations per evaluated case')
        fig.tight_layout();fig.savefig(root/'fig_agent_activations.png',dpi=180);plt.close(fig)
        fig,ax=plt.subplots(figsize=(10,5))
        for policy in policies:
            vals=[s['stats'][policy]['actionable']['rate'] for s in summaries]
            ax.plot(list(range(1,len(vals)+1)),vals,marker='o',label=policy)
        ax.set_xlabel('Independent training replicate');ax.set_ylabel('Recoverable actionable success');ax.set_ylim(0,1.05)
        ax.legend(fontsize=8);fig.tight_layout();fig.savefig(root/'fig_replicate_consistency.png',dpi=180);plt.close(fig)
    except ImportError:
        (root/'PLOTS_UNAVAILABLE.txt').write_text('Install matplotlib to generate figures. Evaluation JSON and CSV were saved.\n')

def run(opts):
    project=Path(__file__).resolve().parent
    root=Path(opts.output).resolve()
    if root.exists():raise FileExistsError(f'Output already exists, refusing to overwrite: {root}')
    if opts.repeats<2 or opts.train<2 or opts.test<1:raise ValueError('Use >=2 repeats, >=2 train seeds, >=1 test seed')
    policies=list(DEFAULT_POLICIES)
    if opts.include_reasoners:policies+=['l1_only','l2_only']
    if opts.allow_openai:
        if not opts.include_reasoners:raise ValueError('--allow-openai requires --include-reasoners')
        policies+=['l3_only']
    root.mkdir(parents=True)
    manifest={'version':'0.8.0','policies':policies,'repeats':opts.repeats,'train_seeds':opts.train,'test_seeds':opts.test,
              'train_disturbances':['relocation','depth_dropout'],'test_disturbances':list(DISTURBANCES),
              'families':list(FAMILIES),'test_seed_offsets':[50000+10000*i for i in range(opts.repeats)],
              'train_seed_offsets':[10000*i for i in range(opts.repeats)],
              'templates':list(TEMPLATES),'openai_enabled':bool(opts.allow_openai),
              'training_rule':'train adaptive using direct literal tasks; frozen during held-out evaluation',
              'unrecoverable_rule':'dual_depth_dropout demands safe abstention; not task completion',
              'no_test_selection':'all failed runs retained; output directory cannot exist before experiment'}
    (root/'protocol.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    all_summaries=[]
    for rep in range(opts.repeats):
        rep_dir=root/f'replicate_{rep+1:03}';rep_dir.mkdir()
        train_offset=10000*rep;test_offset=50000+10000*rep
        memory=rep_dir/'experience'/'adaptive_hybrid.json';memory.parent.mkdir()
        untrained=rep_dir/'experience'/'adaptive_untrained.json';untrained.write_text('{}',encoding='utf-8')
        trainrows=[]
        for case in training_cases(opts.train,train_offset):
            row=run_one(project,rep_dir,case,'adaptive_hybrid',freeze=False,headless=True,
                        memory_path=memory,force_local=True)
            row['policy']='adaptive_train';trainrows.append(row)
            print('TRAIN',rep+1,case_id(case),row.get('environment_outcome'),flush=True)
        testrows=[]
        for case in testing_cases(opts.test,test_offset):
            for policy in policies:
                row=run_one(project,rep_dir,case,policy,allow_openai=opts.allow_openai,
                            freeze=True,headless=True,
                            memory_path=(memory if policy=='adaptive_hybrid' else untrained if policy=='adaptive_untrained' else None))
                testrows.append(row)
                print('TEST',rep+1,case_id(case),policy,'valid=',score(row),'infra=',row.get('infrastructure_error'),flush=True)
        write_rows(rep_dir,trainrows+testrows)
        stats=statistics_for(testrows);paired=paired_comparisons(testrows)
        summary={'replicate':rep+1,'train_offset':train_offset,'test_offset':test_offset,
                 'train_episodes':len(trainrows),'test_episodes':len(testrows),'stats':stats,'paired':paired}
        (rep_dir/'REPLICATE_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        all_summaries.append(summary)
        (root/'PROGRESS.json').write_text(json.dumps({'completed_replicates':len(all_summaries),'target_replicates':opts.repeats},indent=2),encoding='utf-8')
    aggregate=aggregate_repeats(all_summaries)
    (root/'FINAL_RESULTS.json').write_text(json.dumps({'protocol':manifest,'replicates':all_summaries,'paired_across_repeats':aggregate},indent=2),encoding='utf-8')
    report=render_report(root,all_summaries,aggregate,policies,opts)
    plot_results(root,all_summaries,policies)
    print('\n'+report+'\nOutputs: '+str(root))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repeats',type=int,default=2)
    p.add_argument('--train',type=int,default=3)
    p.add_argument('--test',type=int,default=2)
    p.add_argument('--output',default='results/final_confirmatory_pilot')
    p.add_argument('--include-reasoners',action='store_true',help='Add L1-only and always-Ollama on matched embodied tasks')
    p.add_argument('--allow-openai',action='store_true',help='Opt in to real billable always-OpenAI calls; requires --include-reasoners')
    run(p.parse_args())
if __name__=='__main__':main()
