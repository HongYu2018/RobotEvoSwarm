"""Reproducible, fail-inclusive embodied benchmark.

Each subprocess gets its own results directory. Training experience is carried
forward *only within a method*. Test evaluation freezes experience. No LLM is
used by default, isolating coordination from semantic interpretation.
"""
from __future__ import annotations
import argparse, csv, json, subprocess, sys, time
from pathlib import Path
from statistics import mean

MODES=('lean_fixed','reactive_fixed','learned')

def gather(root:Path):
    rows=[]
    for summary in root.glob('runs/**/summary.json'):
        x=json.loads(summary.read_text(encoding='utf-8'))
        rows.append({k:x.get(k) for k in ('scene_seed','split','disturbance','mode','color','success',
                                          'policy_correct','expected_deferral','safe_deferral','placement_error_m','simulation_seconds','wall_seconds',
                                          'sensing_processing_ms','agent_selection_events','agent_activations',
                                          'reasoning_calls','llm_input_tokens','llm_output_tokens','error')})
        rows[-1]['path']=str(summary.relative_to(root))
    return sorted(rows,key=lambda r:(r['split'],r['scene_seed'],r['mode']))

def summarise(rows):
    result={}
    for split in ('train','test'):
        for mode in MODES:
            group=[r for r in rows if r['mode']==mode and r['split']==split]
            if not group:continue
            result[f'{split}/{mode}']={'n':len(group),'successes':sum(bool(r['success']) for r in group),
                'success_rate':round(mean(bool(r['success']) for r in group),4),
                'policy_correct_rate':round(mean(bool(r.get('policy_correct')) for r in group),4),
                'safe_deferrals':sum(bool(r.get('safe_deferral')) for r in group),
                'fault_recovery_success_rate':round(mean(bool(r['success']) for r in group if r.get('disturbance')=='depth_dropout'),4) if any(r.get('disturbance')=='depth_dropout' for r in group) else None,
                'mean_activations':round(mean(r['agent_activations'] or 0 for r in group),3),
                'mean_wall_seconds':round(mean(r['wall_seconds'] or 0 for r in group),4),
                'mean_place_error_m_successes_only':round(mean(r['placement_error_m'] for r in group if r['success'] and r['placement_error_m'] is not None),4) if any(r['success'] and r['placement_error_m'] is not None for r in group) else None}
    return result

def write_table(root, rows):
    if not rows:return
    with (root/'all_runs.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (root/'aggregate.json').write_text(json.dumps(summarise(rows),indent=2),encoding='utf-8')

def run(n_train=4,n_test=6,root='results/study_v06',paper_images=False,split_only=None,disturbances=('relocation','depth_dropout')):
    base=Path(root).resolve()
    if (base/'aggregate.json').exists():
        raise FileExistsError(f'Existing study detected at {base}; choose a new --output to avoid run contamination')
    base.mkdir(parents=True,exist_ok=True)
    for split,n in (('train',n_train),('test',n_test)):
        if split_only and split_only!=split:continue
        for seed in range(n):
            color=('blue','red','yellow')[seed % 3]
            for mode in MODES:
                for disturbance in disturbances:
                    name=f'{split}_s{seed:03}_{mode}_{disturbance}'
                    dest=base/'runs'/name
                    memory=base/'experience'/f'{mode}.json'
                    cmd=[sys.executable,'main.py','--headless','--episodes','1','--hold-seconds','0',
                    '--scene-seed',str(seed),'--split',split,
                    '--scenario','moved','--disturbance',disturbance,'--mode',mode,'--color',color,'--llm-mode','none',
                    '--memory',str(memory),'--output',str(dest)]
                    if split=='test':cmd.append('--freeze-experience')
                    if paper_images and split=='test' and seed < 3:cmd.append('--paper-images')
                    started=time.perf_counter()
                    proc=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
                    (dest/'console.txt').parent.mkdir(parents=True,exist_ok=True)
                    (dest/'console.txt').write_text(proc.stdout+'\nSTDERR:\n'+proc.stderr,encoding='utf-8')
                    (dest/'return_code.txt').write_text(str(proc.returncode),encoding='utf-8')
                    print(f'{name}: exit={proc.returncode} elapsed={time.perf_counter()-started:.2f}s',flush=True)
                    # A failed grasp may return exit code 1 and is a valid experimental outcome.
                    if not list(dest.glob('*/episode_001/summary.json')):
                        (dest/'fatal_failure.txt').write_text('No summary emitted. Inspect console.txt.',encoding='utf-8')
                        # Infrastructure crashes must not disappear from the
                        # sample denominator. Save a separate explicit failure.
                        error_row={'scene_seed':seed,'split':split,'disturbance':disturbance,
                                   'mode':mode,'color':color,'success':False,'policy_correct':False,
                                   'expected_deferral':disturbance=='depth_dropout',
                                   'safe_deferral':False,'placement_error_m':None,
                                   'simulation_seconds':0,'wall_seconds':0,
                                   'sensing_processing_ms':0,'agent_selection_events':0,
                                   'agent_activations':0,'reasoning_calls':0,
                                   'llm_input_tokens':0,'llm_output_tokens':0,
                                   'error':'Infrastructure crash; inspect console.txt'}
                        (dest/'fatal_summary.json').write_text(json.dumps(error_row,indent=2),encoding='utf-8')
    # Existing main produces subfolders named scenario_mode_color/episode_001.
    rows=[]
    for f in list(base.glob('runs/**/summary.json')) + list(base.glob('runs/**/fatal_summary.json')):
        x=json.loads(f.read_text(encoding='utf-8'))
        rows.append({k:x.get(k) for k in ('scene_seed','split','disturbance','mode','color','success',
                 'policy_correct','expected_deferral','safe_deferral','placement_error_m','simulation_seconds','wall_seconds','sensing_processing_ms',
                 'agent_selection_events','agent_activations','reasoning_calls','llm_input_tokens',
                 'llm_output_tokens','error')})
        rows[-1]['path']=str(f.relative_to(base))
    rows.sort(key=lambda r:(r['split'],r['scene_seed'],r['mode']))
    write_table(base,rows)
    print(json.dumps(summarise(rows),indent=2))
    return rows

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train',type=int,default=4)
    p.add_argument('--test',type=int,default=6)
    p.add_argument('--output',default='results/study_v06')
    p.add_argument('--paper-images',action='store_true')
    p.add_argument('--split-only',choices=['train','test'])
    p.add_argument('--disturbances',default='relocation,depth_dropout')
    a=p.parse_args()
    if a.train<0 or a.test<0: p.error('counts cannot be negative')
    run(a.train,a.test,a.output,a.paper_images,a.split_only,tuple(a.disturbances.split(',')))
